"""griplint-gh-dash pipeline: what we lint, with which tables and passes.

Only `config.yml` is linted (YAML). Root from gh-dash.dev/schema.json;\n# `keybindings` and `repoPaths` are user-keyed: FREE_FORM. Sections\n# (prSections/issuesSections) are arrays — entry shape is B0x-later.
"""

from griplint_common import Document, Linter

from . import tables

LINTER = Linter(
    name="gh-dash",
    handles={"config.yml"},
    resolve_table=tables.resolve,
    parse=Document.parse_yaml,
    checks=[],
)
