"""Key tables for gh-dash 4.x, `config.yml`.

Source: gh-dash.dev/schema.json + schema/defaults.json (2026-08).
`keybindings` and `repoPaths` are user-keyed maps → FREE_FORM.
Section arrays (prSections/issuesSections) are type-checked; entry
shape (filters, layout) is B0x-later.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_num = Rule((int, float))
_str = Rule((str,))
_list = Rule((list,))
_table = Rule((dict,))

#: bare root keys — gh-dash.dev/schema.json
ROOT = {
    "confirmQuit": _bool,
    "defaults": _table,
    "include": _list,
    "issuesSections": _list,
    "keybindings": FREE_FORM,
    "pager": _table,
    "prSections": _list,
    "repoPaths": FREE_FORM,
    "showAuthorIcons": _bool,
    "smartFilteringAtLaunch": _bool,
    "theme": _table,
}

DEFAULTS = {  # gh-dash.dev/schema/defaults.json
    "layout": _table,
    "prsLimit": _int,
    "issuesLimit": _int,
    "preview": _table,
    "refetchIntervalMinutes": _int,
    "dateFormat": _int,
    "view": _str,
    "prApproveComment": _str,
}

PREVIEW = {
    "open": _bool,
    "width": _num,
}

TABLES = {
    "": ROOT,
    "defaults": DEFAULTS,
    "defaults.preview": PREVIEW,
}
