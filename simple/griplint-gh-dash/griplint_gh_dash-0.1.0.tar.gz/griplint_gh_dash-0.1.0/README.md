# griplint-gh-dash

Config linter for [gh-dash](https://gh-dash.dev) `config.yml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [linters-py repo](https://github.com/gripsack-dev/linters-py) for usage.
