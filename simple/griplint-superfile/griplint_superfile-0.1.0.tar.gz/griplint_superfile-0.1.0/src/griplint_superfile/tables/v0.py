"""Key tables for superfile 0.x, `config.toml`.

Sources: https://superfile.dev/configure/superfile-config/ plus the
shipped default `src/superfile_config/config.toml` (read 2026-08).
The file is flat — all keys are bare top-level (the "" table).
`[open_with]` maps user extensions to commands: FREE_FORM.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))

#: bare top-level keys — docs: "Setting" / "Style" / "Plugins"
ROOT = {
    # Setting
    "editor": _str,
    "dir_editor": _str,
    "auto_check_update": _bool,
    "cd_on_quit": _bool,
    "default_open_file_preview": _bool,
    "show_image_preview": _bool,
    "show_panel_footer_info": _bool,
    "file_size_use_si": _bool,
    "default_directory": _str,
    "default_sort_type": _int,
    "sort_order_reversed": _bool,
    "case_sensitive_sort": _bool,
    "shell_close_on_success": _bool,
    "debug": _bool,
    "ignore_missing_fields": _bool,
    "page_scroll_size": _int,
    "file_panel_extra_columns": _int,
    "file_panel_name_percent": _int,
    # Style
    "theme": _str,
    "code_previewer": Rule((str,), choices=("", "bat")),
    "nerdfont": _bool,
    "show_select_icons": _bool,
    "transparent_background": _bool,
    "file_preview_width": _int,
    "enable_file_preview_border": _bool,
    "sidebar_width": _int,
    "sidebar_sections": _strs,
    "border_top": _str,
    "border_bottom": _str,
    "border_left": _str,
    "border_right": _str,
    "border_top_left": _str,
    "border_top_right": _str,
    "border_bottom_left": _str,
    "border_bottom_right": _str,
    "border_middle_left": _str,
    "border_middle_right": _str,
    # Plugins
    "metadata": _bool,
    "enable_md5_checksum": _bool,
    "zoxide_support": _bool,
}

TABLES = {
    "": ROOT,
    "open_with": FREE_FORM,  # user extension → command mappings
}
