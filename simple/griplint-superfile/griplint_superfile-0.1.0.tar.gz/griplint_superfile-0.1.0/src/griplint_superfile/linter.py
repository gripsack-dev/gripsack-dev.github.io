"""griplint-superfile pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. `hotkeys.toml` is skipped — binding
#  names are fixed by superfile but the file is a flat action map; a
#  separate table is a later addition. Unknown files are ignored.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="superfile",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
