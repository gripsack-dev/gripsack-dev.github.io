"""griplint-ruff — config linter for ruff (https://docs.astral.sh/ruff)."""

from griplint_common import serve_linter

from .linter import LINTER


def main() -> None:
    serve_linter(LINTER)


if __name__ == "__main__":
    main()
