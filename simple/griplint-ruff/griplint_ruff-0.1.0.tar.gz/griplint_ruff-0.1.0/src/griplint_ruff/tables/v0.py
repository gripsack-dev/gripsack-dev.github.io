"""Key tables for ruff 0.9+, `ruff.toml` and `pyproject.toml`.

Source: docs.astral.sh/ruff/configuration + /settings (read 2026-08) —
root settings, [lint] core options, [format]. Per-plugin option
namespaces (lint.pycodestyle, lint.flake8-*, …) are FREE_FORM: ruff
supports dozens, their keys are plugin-owned. pyproject.toml gets the
same tables under the `tool.ruff` prefix (dispatch in resolve()).
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))

#: bare top-level keys — docs: ruff settings reference
ROOT = {
    "builtins": _strs,
    "cache-dir": _str,
    "extend": _str,
    "extend-exclude": _strs,
    "exclude": _strs,
    "fix": _bool,
    "fix-only": _bool,
    "force-exclude": _bool,
    "indent-width": _int,
    "line-length": _int,
    "log-file": _str,
    "namespace-packages": _strs,
    "output-format": _str,
    "preview": _bool,
    "required-version": _str,
    "respect-gitignore": _bool,
    "src": _strs,
    "target-version": _str,
    "unsafe-fixes": _bool,
    "show-fixes": _bool,
    "extend-safe-fixes": _strs,
}

LINT = {  # docs: [lint] core options
    "select": _strs,
    "ignore": _strs,
    "extend-select": _strs,
    "extend-ignore": _strs,
    "fixable": _strs,
    "unfixable": _strs,
    "extend-fixable": _strs,
    "allowed-confusables": _strs,
    "dummy-variable-rgx": _str,
    "explicit-preview-rules": _bool,
    "extend-safe-fixes": _strs,
    "extend-unsafe-fixes": _strs,
    "external": _strs,
    "ignore-init-module-imports": _bool,
    "logger-objects": _strs,
    "task-tags": _strs,
    "typing-modules": _strs,
    "future-proofing": _bool,
}

FORMAT = {  # docs: [format]
    "quote-style": Rule((str,), choices=("single", "double", "preserve")),
    "indent-style": Rule((str,), choices=("space", "tab")),
    "line-ending": Rule((str,), choices=("auto", "lf", "crlf", "cr")),
    "skip-magic-trailing-comma": _bool,
    "docstring-code-format": _bool,
    "docstring-code-line-length": Rule((str, int)),
    "preview": _bool,
}

#: per-plugin option namespaces — plugin-owned keys (docs: rules index)
LINT_PLUGINS = [
    "isort",
    "pycodestyle",
    "pydocstyle",
    "pyflakes",
    "pylint",
    "mccabe",
    "pep8-naming",
    "pyupgrade",
    "per-file-ignores",
    "flake8-annotations",
    "flake8-async",
    "flake8-bandit",
    "flake8-blind-except",
    "flake8-boolean-trap",
    "flake8-bugbear",
    "flake8-builtins",
    "flake8-commas",
    "flake8-comprehensions",
    "flake8-copyright",
    "flake8-datetimez",
    "flake8-debugger",
    "flake8-errmsg",
    "flake8-executables",
    "flake8-future-annotations",
    "flake8-gettext",
    "flake8-implicit-str-concat",
    "flake8-import-conventions",
    "flake8-logging",
    "flake8-logging-format",
    "flake8-no-pep420",
    "flake8-pie",
    "flake8-print",
    "flake8-pytest-style",
    "flake8-quotes",
    "flake8-raise",
    "flake8-retries",
    "flake8-return",
    "flake8-self",
    "flake8-simplify",
    "flake8-slots",
    "flake8-tidy-imports",
    "flake8-todos",
    "flake8-type-checking",
    "flake8-use-pathlib",
    "fastapi",
    "airflow",
    "pandas-vet",
    "numpy",
    "refurb",
    "ruff",
    "flynt",
    "faust",
]

RUFF_TOML = {
    "": ROOT,
    "lint": LINT,
    "format": FORMAT,
    "extend-per-file-ignores": FREE_FORM,
    **{f"lint.{ns}": FREE_FORM for ns in LINT_PLUGINS},
}

#: same config under [tool.ruff] in pyproject.toml
PYPROJECT_TOML = {
    (f"tool.ruff.{k}" if k else "tool.ruff"): v for k, v in RUFF_TOML.items()
}
