"""Table resolution: per-file dispatch + version coverage.

ruff.toml and pyproject.toml carry the same config at different
roots; the basename picks the table (pyproject goes through the
`tool.ruff` prefix and is linted leniently — see linter.py).
"""

from __future__ import annotations

from griplint_common import Diagnostic, Table

from . import v0

#: Tool-version prefixes our tables are current against.
SUPPORTED = ("0.",)


def resolve(tool_version: str | None, basename: str = "") -> tuple[Table, Diagnostic | None]:
    warning = None
    if tool_version and not tool_version.startswith(SUPPORTED):
        warning = Diagnostic(
            "W10",
            "warning",
            "key tables are written for ruff 0.x; "
            f"this module pins {tool_version} — results may be stale",
        )
    table = v0.PYPROJECT_TOML if basename == "pyproject.toml" else v0.RUFF_TOML
    return table, warning
