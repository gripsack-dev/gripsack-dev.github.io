"""griplint-ruff pipeline: what we lint, with which tables and passes.

Both `ruff.toml` (strict) and `pyproject.toml` [tool.ruff] (lenient —
#  shared file, unknown sections ignored) are linted. Per-plugin option
#  namespaces (lint.flake8-*) are FREE_FORM.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="ruff",
    handles={"ruff.toml", "pyproject.toml"},
    resolve_table=tables.resolve,
    checks=[],
    lenient_basenames={"pyproject.toml"},
)
