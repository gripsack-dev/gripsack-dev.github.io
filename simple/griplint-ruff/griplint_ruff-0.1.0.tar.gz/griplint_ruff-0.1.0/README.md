# griplint-ruff

Config linter for [ruff](https://docs.astral.sh/ruff) `ruff.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
