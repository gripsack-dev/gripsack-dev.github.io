"""griplint-zola pipeline: what we lint, with which tables and passes.

Both `zola.toml` and the legacy `config.toml` fallback are linted.
#  `[extra]`, `[translations]`, and `[languages]` are user-defined: FREE_FORM.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="zola",
    handles={"zola.toml", "config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
