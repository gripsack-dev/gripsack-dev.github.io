"""Key tables for zola 0.x, `zola.toml`.

Source: https://www.getzola.org/documentation/getting-started/configuration/
(read 2026-08). Sections per the docs: main (bare), markdown,
markdown.highlighting, link_checker, slugify, search; translations,
languages, and extra are user-defined → FREE_FORM.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))

#: bare top-level keys — docs: "main (unnamed)"; base_url is the only
#: required key (not enforced at v1)
ROOT = {
    "base_url": _str,
    "title": _str,
    "description": _str,
    "default_language": _str,
    "theme": _str,
    "output_dir": _str,
    "preserve_dotfiles_in_output": _bool,
    "compile_sass": _bool,
    "minify_html": _bool,
    "ignored_content": _strs,
    "skip_content_templating": _strs,
    "ignored_static": _strs,
    "generate_feeds": _bool,
    "exclude_paginated_pages_in_sitemap": Rule((str,), choices=("none", "all")),
    "feed_filenames": _strs,
    "feed_limit": _int,
    "hard_link_static": _bool,
    "author": _str,
    "taxonomies": Rule((list,)),
    "taxonomy_root": _str,
    "build_search_index": _bool,
    "generate_sitemap": _bool,
    "generate_robots_txt": _bool,
}

MARKDOWN = {  # docs: [markdown]
    "render_emoji": _bool,
    "external_links_class": _str,
    "external_links_target_blank": _bool,
    "external_links_no_follow": _bool,
    "external_links_no_referrer": _bool,
    "external_links_external": _bool,
    "smart_punctuation": _bool,
    "definition_list": _bool,
    "lazy_async_image": _bool,
    "bottom_footnotes": _bool,
    "github_alerts": _bool,
    "insert_anchor_links": Rule((str,), choices=("left", "right", "heading", "none")),
}

HIGHLIGHTING = {  # docs: [markdown.highlighting]
    "error_on_missing_language": _bool,
    "style": Rule((str,), choices=("inline", "class")),
    "theme": _str,
    "light_theme": _str,
    "dark_theme": _str,
    "extra_grammars": _strs,
    "extra_themes": _strs,
    "data_attr_position": Rule((str,), choices=("code", "pre", "both", "none")),
    "add_color_scheme": _bool,
}

LINK_CHECKER = {  # docs: [link_checker]
    "skip_prefixes": _strs,
    "skip_anchor_prefixes": _strs,
    "internal_level": Rule((str,), choices=("error", "warn")),
    "external_level": Rule((str,), choices=("error", "warn")),
}

SLUGIFY = {  # docs: [slugify]
    "paths": Rule((str,), choices=("on", "off", "safe")),
    "taxonomies": Rule((str,), choices=("on", "off", "safe")),
    "anchors": Rule((str,), choices=("on", "off", "safe")),
    "paths_keep_dates": _bool,
}

SEARCH = {  # docs: [search]
    "include_title": _bool,
    "include_description": _bool,
    "include_date": _bool,
    "include_path": _bool,
    "include_content": _bool,
    "truncate_content_length": _int,
    "index_format": Rule(
        (str,),
        choices=(
            "elasticlunr_javascript",
            "elasticlunr_json",
            "fuse_javascript",
            "fuse_json",
        ),
    ),
}

TABLES = {
    "": ROOT,
    "markdown": MARKDOWN,
    "markdown.highlighting": HIGHLIGHTING,
    "link_checker": LINK_CHECKER,
    "slugify": SLUGIFY,
    "search": SEARCH,
    "translations": FREE_FORM,  # translation keys are user-defined
    "languages": FREE_FORM,  # language codes are user-defined
    "extra": FREE_FORM,  # theme/user data by definition
}
