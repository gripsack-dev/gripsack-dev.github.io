# griplint-zola

Config linter for [zola](https://www.getzola.org) `zola.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
