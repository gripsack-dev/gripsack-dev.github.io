"""Key tables for git-cliff 2.x, `cliff.toml`.

Sources: the shipped default config
(github.com/orhun/git-cliff/blob/main/config/cliff.toml — the
authoritative key list for [changelog] and [git]) plus the documented
env-override keys (footer, ignore_tags) and the remote-integration
fixtures ([remote.github] owner/repo/token). `[remote]` is FREE_FORM:
each forge has its own sub-table (TODO(coverage): tabulate
remote.github/gitlab/gitea/bitbucket).
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_str = Rule((str,))
_strs = Rule((list,))

CHANGELOG = {  # source: default cliff.toml + env-override docs
    "body": _str,
    "header": _str,
    "footer": _str,
    "trim": _bool,
    "render_always": _bool,
    "postprocessors": _strs,
    "output": _str,
}

GIT = {  # source: default cliff.toml + env-override docs
    "conventional_commits": _bool,
    "filter_unconventional": _bool,
    "require_conventional": _bool,
    "split_commits": _bool,
    "commit_preprocessors": _strs,
    "protect_breaking_commits": _bool,
    "commit_parsers": _strs,
    "filter_commits": _bool,
    "fail_on_unmatched_commit": _bool,
    "link_parsers": _strs,
    "use_branch_tags": _bool,
    "topo_order": _bool,
    "topo_order_commits": _bool,
    "sort_commits": Rule((str,), choices=("newest", "oldest")),
    "recurse_submodules": _bool,
    "ignore_tags": _str,
}

TABLES = {
    "changelog": CHANGELOG,
    "git": GIT,
    "remote": FREE_FORM,  # TODO(coverage): remote.github/gitlab/gitea/bitbucket
}
