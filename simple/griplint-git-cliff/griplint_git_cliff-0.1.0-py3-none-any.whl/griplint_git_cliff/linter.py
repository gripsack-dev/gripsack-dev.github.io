"""griplint-git-cliff pipeline: what we lint, with which tables and passes.

Only `cliff.toml` is linted (also discovered as `.cliff.toml`? no — cliff.toml and cliff.toml only per docs). Unknown files are ignored.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="git-cliff",
    handles={"cliff.toml", ".cliff.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
