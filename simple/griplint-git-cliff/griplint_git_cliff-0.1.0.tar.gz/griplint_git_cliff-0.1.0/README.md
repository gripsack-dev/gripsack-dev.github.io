# griplint-git-cliff

Config linter for [git-cliff](https://git-cliff.org) `cliff.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
