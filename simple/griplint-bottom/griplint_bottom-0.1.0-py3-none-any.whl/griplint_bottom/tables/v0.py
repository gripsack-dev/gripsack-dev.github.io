"""Key tables for bottom 0.10+, `bottom.toml`.

Source: the official JSON schema (derived, per the author skill's
machine-readable-first rule) —
github.com/ClementTsang/bottom/blob/main/schema/nightly/bottom.json,
expanded 2026-08. Schema nullability stripped (TOML has no null);
mixed int|str keys are durations ("1s" or a number). `[row]` is a
user-composed layout tree → FREE_FORM; style sub-tables and *_filter
tables are type-checked only (TODO(coverage): their inner keys).
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))
_duration = Rule((int, str))  # number or "1s"-style string

CPU = {  # schema: CpuConfig
    "basic_average_cpu_row": _bool,
    "default": Rule((str,), choices=("all", "average")),
    "hide_avg_cpu": _bool,
    "left_legend": _bool,
    "show_decimal": _bool,
}

DISK = {  # schema: DiskConfig
    "columns": _strs,
    "default_sort": _str,
    "include_unmounted": _bool,
    "mount_filter": _table,
    "name_filter": _table,
    "sort_order": Rule((str,), choices=("Ascending", "Descending")),
}

DISK_IO_GRAPH = {  # schema: DiskIoGraphConfig
    "include_unmounted": _bool,
    "legend": _table,
    "legend_position": _str,
    "name_filter": _table,
    "show_read": _bool,
    "show_write": _bool,
    "use_log": _bool,
}

FLAGS = {  # schema: GeneralConfig (44 keys)
    "autohide_time": _bool,
    "average_cpu_row": _bool,
    "basic": _bool,
    "battery": _bool,
    "case_sensitive": _bool,
    "cpu_left_legend": _bool,
    "current_usage": _bool,
    "default_time_value": _duration,
    "default_widget_count": _int,
    "default_widget_type": _str,
    "disable_advanced_kill": _bool,
    "disable_click": _bool,
    "disable_gpu": _bool,
    "disable_keys": _bool,
    "dot_marker": _bool,
    "enable_cache_memory": _bool,
    "expanded": _bool,
    "free_arc": _bool,
    "group_processes": _bool,
    "hide_avg_cpu": _bool,
    "hide_k_threads": _bool,
    "hide_time": _bool,
    "memory_legend": _str,
    "network_legend": _str,
    "network_use_binary_prefix": _bool,
    "network_use_bytes": _bool,
    "network_use_log": _bool,
    "no_write": _bool,
    "process_command": _bool,
    "process_memory_as_value": _bool,
    "rate": _duration,
    "read_only": _bool,
    "regex": _bool,
    "retention": _duration,
    "show_table_scroll_bar": _bool,
    "show_table_scroll_position": _bool,
    "table_gap": Rule((str,), choices=("none", "space", "line")),
    "temperature_type": _str,
    "time_delta": _duration,
    "tree": _bool,
    "tree_collapse": _bool,
    "unnormalized_cpu": _bool,
    "use_old_network_legend": _bool,
    "whole_word": _bool,
}

MEMORY_GRAPH = {  # schema: MemoryGraphConfig
    "cache_memory": _bool,
    "free_arc": _bool,
    "legend_position": _str,
    "short_gpu_names": _bool,
}

NETWORK_GRAPH = {  # schema: NetworkGraphConfig
    "interface_filter": _table,
    "legend_position": _str,
    "show_packets": _bool,
    "start_zeroed": _bool,
    "use_binary_prefix": _bool,
    "use_bytes": _bool,
    "use_log": _bool,
}

PROCESSES = {  # schema: ProcessesConfig
    "case_sensitive": _bool,
    "columns": _strs,
    "current_usage": _bool,
    "default_grouped": _bool,
    "default_memory_value": _bool,
    "default_sort": _str,
    "default_tree": _bool,
    "disable_advanced_kill": _bool,
    "get_threads": _bool,
    "hide_k_threads": _bool,
    "process_command": _bool,
    "regex": _bool,
    "sort_order": Rule((str,), choices=("Ascending", "Descending")),
    "tree_collapse": _bool,
    "unnormalized_cpu": _bool,
    "whole_word": _bool,
}

STYLES = {  # schema: StyleConfig — sub-tables type-checked only
    "battery": _table,
    "cpu": _table,
    "disk_io_graph": _table,
    "graphs": _table,
    "memory": _table,
    "network": _table,
    "tables": _table,
    "temp_graph": _table,
    "theme": _str,
    "widgets": _table,
}

TEMPERATURE = {  # schema: TempConfig
    "default_sort": _str,
    "sensor_filter": _table,
    "sort_order": Rule((str,), choices=("Ascending", "Descending")),
}

TEMPERATURE_GRAPH = {  # schema: TempGraphConfig
    "legend_position": _str,
    "max_temp": Rule((int, float)),
    "sensor_filter": _table,
}

TABLES = {
    "cpu": CPU,
    "disk": DISK,
    "disk_io_graph": DISK_IO_GRAPH,
    "flags": FLAGS,
    "memory_graph": MEMORY_GRAPH,
    "network_graph": NETWORK_GRAPH,
    "processes": PROCESSES,
    "row": FREE_FORM,  # user-composed layout tree
    "styles": STYLES,
    "temperature": TEMPERATURE,
    "temperature_graph": TEMPERATURE_GRAPH,
}
