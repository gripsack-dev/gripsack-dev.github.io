"""griplint-bottom pipeline: what we lint, with which tables and passes.

Only `bottom.toml` is linted. `[row]` (the layout tree) and style
#  sub-tables are FREE_FORM — layout widgets and per-widget style keys are
#  user-composed; the engine checks their table type only.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="bottom",
    handles={"bottom.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
