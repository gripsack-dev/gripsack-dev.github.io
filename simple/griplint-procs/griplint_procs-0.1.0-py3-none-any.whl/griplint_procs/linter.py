"""griplint-procs pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted (the legacy `~/.procs.toml` shares the
#  format but is out of path scope). `[[columns]]` entries are type-checked;
#  kind/style vocabulary is documented but left to a later B0x check.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="procs",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
