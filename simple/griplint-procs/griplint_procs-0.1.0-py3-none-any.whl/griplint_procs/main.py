"""griplint-procs — config linter for procs (https://github.com/dalance/procs)."""

from griplint_common import serve_linter

from .linter import LINTER


def main() -> None:
    serve_linter(LINTER)


if __name__ == "__main__":
    main()
