"""Key tables for procs 0.x, `config.toml`.

Source: github.com/dalance/procs README "Configuration" (read 2026-08)
— the complete `--gen-config` example plus the [[columns]] and [style]
key tables. `[[columns]]` entries are arrays of tables: type-checked
only at v1 (TODO: B0x check for the kind/style vocabulary).
[style.by_*] color keys are fixed per the README table.
"""

from griplint_common import Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))

STYLE = {  # README: [style] section table
    "header": _str,
    "unit": _str,
    "tree": _str,
}

STYLE_BY_PERCENTAGE = {  # README: by_percentage rows
    "color_000": _str,
    "color_025": _str,
    "color_050": _str,
    "color_075": _str,
    "color_100": _str,
}

STYLE_BY_STATE = {  # README: by_state rows
    "color_d": _str,
    "color_r": _str,
    "color_s": _str,
    "color_t": _str,
    "color_z": _str,
    "color_x": _str,
    "color_k": _str,
    "color_w": _str,
    "color_p": _str,
}

STYLE_BY_UNIT = {  # README: by_unit rows
    "color_k": _str,
    "color_m": _str,
    "color_g": _str,
    "color_t": _str,
    "color_p": _str,
    "color_x": _str,
}

SEARCH = {  # README: [search]
    "numeric_search": Rule((str,), choices=("Exact", "Partial")),
    "nonnumeric_search": Rule((str,), choices=("Exact", "Partial")),
    "logic": Rule((str,), choices=("And", "Or")),
}

DISPLAY = {  # README: [display]
    "show_self": _bool,
    "show_thread": _bool,
    "show_thread_in_tree": _bool,
    "cut_to_terminal": _bool,
    "cut_to_pager": _bool,
    "cut_to_pipe": _bool,
    "color_mode": Rule((str,), choices=("Auto", "Always", "Never")),
}

SORT = {  # README: [sort]
    "column": _int,
    "order": Rule((str,), choices=("Ascending", "Descending")),
}

DOCKER = {  # README: [docker]
    "path": _str,
}

PAGER = {  # README: [pager]
    "mode": _str,
}

#: the config is all sections; [[columns]] is an array of tables
ROOT = {
    "columns": _strs,  # type-checked as list; entry shape is B0x-later
}

TABLES = {
    "": ROOT,
    "style": STYLE,
    "style.by_percentage": STYLE_BY_PERCENTAGE,
    "style.by_state": STYLE_BY_STATE,
    "style.by_unit": STYLE_BY_UNIT,
    "search": SEARCH,
    "display": DISPLAY,
    "sort": SORT,
    "docker": DOCKER,
    "pager": PAGER,
}
