# griplint-procs

Config linter for [procs](https://github.com/dalance/procs) `config.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
