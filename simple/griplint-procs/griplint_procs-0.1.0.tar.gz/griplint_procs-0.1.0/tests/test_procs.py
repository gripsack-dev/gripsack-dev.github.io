"""griplint-procs: behavior pinned by fixtures."""

from pathlib import Path

import pytest
from griplint_common.fixtures import check_fixtures, iter_cases, run_case
from griplint_procs.linter import LINTER

FIXTURES = Path(__file__).parent / "fixtures"


def test_fixtures():
    check_fixtures(LINTER, FIXTURES)


@pytest.mark.parametrize("case", sorted(iter_cases(FIXTURES)), ids=lambda c: c.name)
def test_case(case):
    assert run_case(LINTER, case) == []
