# griplint-glow

Config linter for [glow](https://github.com/charmbracelet/glow) `glow.yml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [linters-py repo](https://github.com/gripsack-dev/linters-py) for usage.
