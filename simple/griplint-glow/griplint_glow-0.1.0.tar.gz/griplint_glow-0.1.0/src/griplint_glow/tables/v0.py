"""Key tables for glow 2.x, `glow.yml`.

Source: charmbracelet/glow README "The Config File" (read 2026-08) —
the config is seven flat keys, all bare root level.
"""

from griplint_common import Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))

#: bare root keys — README example config
ROOT = {
    "style": _str,
    "mouse": _bool,
    "pager": _bool,
    "width": _int,
    "all": _bool,
    "showLineNumbers": _bool,
    "preserveNewLines": _bool,
}

TABLES = {
    "": ROOT,
}
