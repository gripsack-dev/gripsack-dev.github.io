"""griplint-glow pipeline: what we lint, with which tables and passes.

Only `glow.yml` is linted (YAML — first parse_yaml consumer).\n# The config is seven flat keys; unknown files are ignored.
"""

from griplint_common import Document, Linter

from . import tables

LINTER = Linter(
    name="glow",
    handles={"glow.yml"},
    resolve_table=tables.resolve,
    parse=Document.parse_yaml,
    checks=[],
)
