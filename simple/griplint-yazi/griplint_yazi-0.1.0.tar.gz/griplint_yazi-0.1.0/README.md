# griplint-yazi

Config linter for [yazi](https://yazi-rs.github.io) `yazi.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
