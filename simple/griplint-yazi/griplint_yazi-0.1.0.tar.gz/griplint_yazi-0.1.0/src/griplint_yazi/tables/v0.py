"""Key tables for yazi 25.x/26.x — one table per config file.

Sources: yazi-rs.github.io/docs/configuration/yazi (v26.8.15 docs,
read 2026-08) for yazi.toml; /docs/configuration/keymap for the
keymap sections. Per-file dispatch in `resolve()` (tables/__init__).

- yazi.toml: [mgr] [preview] [opener] [open] [tasks] [plugin] [input]
  [confirm] [pick] [which] — tabulated; [opener]/[open]/[plugin] rule
  arrays are type-checked (their `use`/`run` vocabulary is B0x-later).
- keymap.toml: the eight keymap sections × keymap/prepend_keymap/
  append_keymap arrays.
- theme.toml: known section names, style bodies FREE_FORM.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_num = Rule((int, float))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))

MGR = {  # docs: [mgr]
    "ratio": Rule((list,)),  # 3-element
    "sort_by": Rule(
        (str,),
        choices=(
            "none",
            "mtime",
            "btime",
            "extension",
            "alphabetical",
            "natural",
            "size",
            "random",
        ),
    ),
    "sort_sensitive": _bool,
    "sort_reverse": _bool,
    "sort_dir_first": _bool,
    "sort_translit": _bool,
    "linemode": _str,  # built-ins or a plugin-provided custom name
    "show_hidden": _bool,
    "show_symlink": _bool,
    "scrolloff": _int,
    "mouse_events": Rule(
        (list,),
        # entries: "click", "scroll", "touch", "move", "drag"
    ),
}

PREVIEW = {  # docs: [preview]
    "wrap": Rule((str,), choices=("yes", "no")),
    "tab_size": _int,
    "max_width": _int,
    "max_height": _int,
    "cache_dir": _str,
    "image_delay": _int,
    "image_filter": Rule((str,), choices=("nearest", "triangle", "catmull-rom", "lanczos3")),
    "image_quality": _int,
    "ueberzug_scale": _num,
    "ueberzug_offset": Rule((list,)),  # [x, y, w, h]
}

OPENER = FREE_FORM  # user-named openers, arrays of rule tables

OPEN = {  # docs: [open]
    "rules": Rule((list,)),
    "prepend_rules": Rule((list,)),
    "append_rules": Rule((list,)),
}

TASKS = {  # docs: [tasks]
    "file_workers": _int,
    "plugin_workers": _int,
    "fetch_workers": _int,
    "preload_workers": _int,
    "process_workers": _int,
    "bizarre_retry": _int,
    "suppress_preload": _bool,
    "image_alloc": _int,
    "image_bound": Rule((list,)),  # [width, height]
}

PLUGIN = {  # docs: [plugin] — rule arrays, type-checked
    "fetchers": Rule((list,)),
    "prepend_fetchers": Rule((list,)),
    "append_fetchers": Rule((list,)),
    "previewers": Rule((list,)),
    "prepend_previewers": Rule((list,)),
    "append_previewers": Rule((list,)),
    "preloaders": Rule((list,)),
    "prepend_preloaders": Rule((list,)),
    "append_preloaders": Rule((list,)),
}

WHICH = {  # docs: [which]
    "sort_by": Rule((str,), choices=("none", "key", "desc")),
    "sort_sensitive": _bool,
    "sort_reverse": _bool,
    "sort_translit": _bool,
}


def _component(names):
    """Per-component title/origin/offset keys, e.g. cd_title (docs:
    [input] — inputs cd/create/rename/filter/find/search/shell; title
    is a string or a 2-tuple for create/find/shell)."""
    out = {"cursor_blink": _bool}
    for n in names:
        out[f"{n}_origin"] = _str
        out[f"{n}_offset"] = Rule((list,))
        out[f"{n}_title"] = Rule((str, list))
    return out


INPUT = _component(["cd", "create", "rename", "filter", "find", "search", "shell"])
CONFIRM = _component(["trash", "delete", "overwrite", "quit"])
PICK = _component(["open"])

YAZI_TOML = {
    "mgr": MGR,
    "preview": PREVIEW,
    "opener": OPENER,
    "open": OPEN,
    "tasks": TASKS,
    "plugin": PLUGIN,
    "input": INPUT,
    "confirm": CONFIRM,
    "pick": PICK,
    "which": WHICH,
    "log": FREE_FORM,  # undocumented at docs-time; keep permissive
}

_KEYMAP_SECTION = {
    "keymap": Rule((list,)),
    "prepend_keymap": Rule((list,)),
    "append_keymap": Rule((list,)),
}

KEYMAP_TOML = {  # docs: keymap page sections
    name: dict(_KEYMAP_SECTION)
    for name in ("mgr", "tasks", "select", "spot", "pick", "input", "confirm", "help")
}

#: theme.toml: section names are fixed, style bodies are open by design
THEME_TOML = {
    name: FREE_FORM
    for name in (
        "mgr",
        "tabs",
        "mode",
        "status",
        "help",
        "notify",
        "pick",
        "input",
        "confirm",
        "completion",
        "tasks",
        "which",
        "filetype",
    )
}

TABLES_BY_FILE = {
    "yazi.toml": YAZI_TOML,
    "keymap.toml": KEYMAP_TOML,
    "theme.toml": THEME_TOML,
}
