"""Table resolution: per-file dispatch + version coverage.

yazi ships three config files with different shapes; the basename
picks the table. Nearest-match with a coverage warning, never a hard
failure (see the repo author skill).
"""

from __future__ import annotations

from griplint_common import Diagnostic, Table

from . import v0

#: Tool-version prefixes our tables are current against (docs 26.8.15).
SUPPORTED = ("25.", "26.")


def resolve(tool_version: str | None, basename: str = "") -> tuple[Table, Diagnostic | None]:
    warning = None
    if tool_version and not tool_version.startswith(SUPPORTED):
        warning = Diagnostic(
            "W10",
            "warning",
            "key tables are written for yazi 25.x/26.x; "
            f"this module pins {tool_version} — results may be stale",
        )
    return v0.TABLES_BY_FILE.get(basename, v0.YAZI_TOML), warning
