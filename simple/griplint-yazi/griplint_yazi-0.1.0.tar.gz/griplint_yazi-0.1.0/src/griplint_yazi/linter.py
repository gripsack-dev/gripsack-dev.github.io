"""griplint-yazi pipeline: what we lint, with which tables and passes.

All three yazi config files are linted — yazi.toml, keymap.toml,
#  theme.toml — with per-file tables (resolve dispatches on basename).
#  theme.toml style bodies are open by design: section names checked,
#  style keys FREE_FORM.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="yazi",
    handles={"yazi.toml", "keymap.toml", "theme.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
