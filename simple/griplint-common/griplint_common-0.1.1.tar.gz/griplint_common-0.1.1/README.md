# griplint-common

Protocol and helpers for `griplint-*` config validation plugins (gripsack plan/0011). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for the plugin-author contract.
