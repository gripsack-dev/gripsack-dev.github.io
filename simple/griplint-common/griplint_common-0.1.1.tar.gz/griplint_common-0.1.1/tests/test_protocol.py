"""Protocol + pipeline contract tests."""

import json
import subprocess
import sys
from pathlib import Path

from griplint_common import FREE_FORM, Diagnostic, Document, Linter, Rule, table_check

SRC = Path(__file__).parent.parent / "src"

TABLES = {
    "": {"theme": Rule((str,))},
    "editor": {
        "scrolloff": Rule((int,)),
        "line-number": Rule((str,), choices=("absolute", "relative")),
    },
    "keys": FREE_FORM,
}


def _doc(text, path="/c.toml"):
    parsed = Document.parse_toml(path, text)
    assert isinstance(parsed, Document), parsed
    return parsed


def test_unknown_key_points_at_the_line_with_a_suggestion():
    (d,) = table_check(_doc('theme = "x"\n\n[editor]\nscrollof = 5\n'), TABLES)
    assert d.code == "A01"
    assert d.severity == "error"
    assert "scrollof" in d.message
    assert d.help == "did you mean 'scrolloff'?"
    assert d.labels[0]["span"]["line"] == 4


def test_wrong_type_and_bad_choice():
    type_err, choice_err = table_check(
        _doc('[editor]\nscrolloff = "five"\nline-number = "sideways"\n'), TABLES
    )
    assert type_err.code == "A04" and "integer" in type_err.message
    assert choice_err.code == "A05" and "absolute" in choice_err.message


def test_bool_is_not_an_int():
    (d,) = table_check(_doc("[editor]\nscrolloff = true\n"), TABLES)
    assert d.code == "A04"


def test_free_form_section_passes_anything():
    doc = _doc('[keys.normal]\nsomething = "anything"\n[keys]\nx = 1\n')
    tables = {"keys": FREE_FORM, "keys.normal": FREE_FORM}
    assert table_check(doc, tables) == []


def test_unknown_section_suggests():
    (d,) = table_check(_doc("[edtor]\nscrolloff = 5\n"), TABLES)
    assert d.code == "A02"
    assert d.help == "did you mean [editor]?"
    assert d.labels[0]["span"]["line"] == 1


def test_parse_error_is_a_diagnostic_with_a_span():
    parsed = Document.parse_toml("/c.toml", "[editor\nscrolloff = 5\n")
    assert isinstance(parsed, Diagnostic)
    assert parsed.code == "A00"
    assert parsed.labels[0]["span"]["line"] == 1


def test_deprecated_key_is_a_warning_with_the_rename():
    tables = {"editor": {"old-key": Rule((bool,), deprecated="new-key")}}
    (d,) = table_check(_doc("[editor]\nold-key = true\n"), tables)
    assert d.severity == "warning"
    assert "renamed to 'new-key'" in d.help


def test_extra_checks_run_after_the_table_engine():
    def no_dark_themes(doc, table):
        theme = doc.data.get("theme")
        if theme == "dark":
            yield Diagnostic("B01", "warning", "dark themes are for the brave", doc.label("", "theme"))

    linter = Linter(
        name="demo",
        handles={"config.toml"},
        resolve_table=lambda v, b="": (TABLES, None),
        checks=[no_dark_themes],
    )
    codes = [d.code for d in linter.lint_file("/c/config.toml", 'theme = "dark"\nscrollof = 1\n', None)]
    assert codes == ["B01", "A01"] or codes == ["A01", "B01"]
    assert "B01" in codes and "A01" in codes


def test_linter_ignores_files_it_does_not_handle():
    linter = Linter(name="demo", handles={"config.toml"}, resolve_table=lambda v, b="": (TABLES, None))
    assert linter.lint_file("/c/other.toml", "not toml [[[", None) == []


def _run_serve(stdin: str):
    code = (
        "from griplint_common import serve, Diagnostic\n"
        "serve('demo', lambda p, t, v: [Diagnostic('A01', 'error', 'bad', "
        "[{'span': {'file': p, 'line': 1}, 'note': ''}])])\n"
    )
    return subprocess.run(  # noqa: PLW1510 — returncode is the assertion
        [sys.executable, "-c", code],
        input=stdin,
        capture_output=True,
        text=True,
        cwd=str(SRC),
    )


def test_serve_roundtrip_codespaces_and_responds(tmp_path):
    f = tmp_path / "a.toml"
    f.write_text("x = 1\n")
    proc = _run_serve(json.dumps({"op": "lint", "paths": [str(f)], "tool_version": None}) + "\n")
    assert proc.returncode == 0, proc.stderr
    messages = [json.loads(line) for line in proc.stdout.splitlines()]
    assert messages[-1]["type"] == "response"
    assert messages[-1]["result"] == {"linted": 1}
    diag = messages[0]["diagnostic"]
    assert diag["code"] == "griplint-demo/A01"  # codespaced by the host
    assert diag["labels"][0]["span"]["file"] == str(f)


def test_serve_crashing_linter_fails_one_file_not_the_eval(tmp_path):
    f = tmp_path / "a.toml"
    f.write_text("x = 1\n")
    code = "from griplint_common import serve\nserve('demo', lambda p, t, v: 1 / 0)\n"
    proc = subprocess.run(  # noqa: PLW1510 — testing the crash path
        [sys.executable, "-c", code],
        input=json.dumps({"op": "lint", "paths": [str(f)], "tool_version": None}) + "\n",
        capture_output=True,
        text=True,
        cwd=str(SRC),
    )
    messages = [json.loads(line) for line in proc.stdout.splitlines()]
    assert messages[0]["diagnostic"]["code"] == "griplint-demo/E99"
    assert messages[-1]["type"] == "response"
