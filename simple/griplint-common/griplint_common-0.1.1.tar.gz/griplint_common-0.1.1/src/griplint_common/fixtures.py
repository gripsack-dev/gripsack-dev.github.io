"""Fixture harness: input file → expected diagnostics file.

One directory per case under `tests/fixtures/`:

    tests/fixtures/typo-in-editor/
    ├── config.toml       the config file — under its REAL name, since
    │                     linters dispatch on basename
    ├── expected.json     the expected diagnostics (see below)
    └── tool_version      optional — one line, e.g. "25.07.1"

`expected.json` is a JSON list of diagnostic dicts in the linter's
emitted shape (`Diagnostic.to_dict()`), with the literal string
`<input>` wherever a span would name the file — the harness
substitutes the real path. Diagnostics must match in order; author the
file by running the linter once and pasting verified output.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from .linter import Linter

INPUT_PLACEHOLDER = "<input>"


def iter_cases(fixtures_dir: Path) -> Iterator[Path]:
    """Case directories, sorted — a case has exactly one config file."""
    for case in sorted(fixtures_dir.iterdir()):
        if case.is_dir() and (case / "expected.json").exists():
            yield case


def _input_file(case: Path) -> Path:
    (match,) = [f for f in case.iterdir() if f.name not in ("expected.json", "tool_version")]
    return match


def _normalize(diagnostic: dict[str, Any], input_path: Path) -> dict[str, Any]:
    """The inverse of authoring: swap the real input path for the
    placeholder so fixture files stay checkout-location independent."""
    text = json.dumps(diagnostic)
    return json.loads(text.replace(str(input_path), INPUT_PLACEHOLDER))


def run_case(linter: Linter, case: Path) -> list[str]:
    """Run one case; returns mismatch descriptions ([] = pass)."""
    input_path = _input_file(case)
    tool_version_file = case / "tool_version"
    tool_version = tool_version_file.read_text().strip() if tool_version_file.exists() else None
    actual = [
        _normalize(d.to_dict(), input_path)
        for d in linter.lint_file(str(input_path), input_path.read_text(), tool_version)
    ]
    expected = json.loads((case / "expected.json").read_text())
    if actual == expected:
        return []
    return [
        (
            f"{case.name}: diagnostics differ\n"
            f"  expected: {json.dumps(expected, indent=2)}\n"
            f"  actual:   {json.dumps(actual, indent=2)}"
        )
    ]


def check_fixtures(linter: Linter, fixtures_dir: Path) -> None:
    """Pytest-ready gate: every case passes, and there IS at least one
    case — an empty fixtures dir is a mistake, not a success."""
    cases = list(iter_cases(fixtures_dir))
    assert cases, f"no fixture cases in {fixtures_dir}"
    failures = []
    for case in cases:
        failures.extend(run_case(linter, case))
    assert not failures, "\n\n".join(failures)
