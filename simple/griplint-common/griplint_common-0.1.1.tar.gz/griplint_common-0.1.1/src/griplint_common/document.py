"""A parsed config document: data + spans, the input every check sees.

Parse once (stdlib tomllib is authoritative for values), scan once for
spans — checks never re-parse and never re-locate keys. TOML today;
YAML/JSON documents slot in here when a linter needs them (the check
pipeline doesn't change).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

import tomllib

from .protocol import Diagnostic, label


@dataclass(frozen=True)
class KeySpan:
    line: int
    col: int


_SECTION_RE = re.compile(r"^\s*\[\[?\s*([\w.\-]+)\s*\]?\]")
_KEY_RE = re.compile(r'^\s*([A-Za-z0-9_\-]+)\s*=')

#: spans key for a section header itself: ("__section__", dotted.name)
SECTION = "__section__"


def _scan_spans(text: str) -> dict[tuple[str, str], KeySpan]:
    """(section, key) → position, from a line walk. Handles the 99%:
    `[section]` headers and `key = value` lines. Dotted section headers
    flatten to dotted paths, matching how key tables are keyed."""
    spans: dict[tuple[str, str], KeySpan] = {}
    section = ""
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#", 1)[0] if not raw.lstrip().startswith("#") else ""
        m = _SECTION_RE.match(line)
        if m:
            section = m.group(1)
            spans.setdefault((SECTION, section), KeySpan(lineno, raw.index("[") + 1))
            continue
        m = _KEY_RE.match(line)
        if m:
            col = raw.index(m.group(1)) + 1
            spans.setdefault((section, m.group(1)), KeySpan(lineno, col))
    return spans


def _toml_error_span(message: str) -> tuple[int, int]:
    m = re.search(r"\(at line (\d+), column (\d+)\)", message)
    if m:
        return int(m.group(1)), int(m.group(2))
    return 1, 1


def _scan_json_spans(text: str) -> dict[tuple[str, str], KeySpan]:
    """(section, key) → position for JSON, from a small token scanner:
    strings (with escapes), brackets, and punctuation. Object paths
    are dotted like TOML sections; array members are not addressable
    at v1 (same as TOML/YAML arrays)."""
    import bisect

    spans: dict[tuple[str, str], KeySpan] = {}
    line_starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            line_starts.append(i + 1)

    def line_col(offset: int) -> tuple[int, int]:
        line = bisect.bisect_right(line_starts, offset)
        return line, offset - line_starts[line - 1] + 1

    token = re.compile(r'"(?:\\.|[^"\\])*"|[{}\[\]:,]|\S')
    path: list[str] = []
    expect_key: list[bool] = []  # per open object: next string is a key
    array_depth = 0
    pending_key: str | None = None
    for m in token.finditer(text):
        tok = m.group(0)
        if tok == "[":
            array_depth += 1
            pending_key = None
        elif tok == "]":
            array_depth -= 1
            if array_depth == 0 and expect_key:
                expect_key[-1] = True
        elif array_depth > 0:
            continue
        elif tok == "{":
            if pending_key is not None:
                path.append(pending_key)
                pending_key = None
            expect_key.append(True)
        elif tok == "}":
            expect_key.pop()
            if path:
                path.pop()
            if expect_key:
                expect_key[-1] = True
        elif tok == ",":
            if expect_key:
                expect_key[-1] = True
        elif tok.startswith('"') and expect_key:
            if expect_key[-1]:
                key = json.loads(tok)
                section = ".".join(path)
                line, col = line_col(m.start())
                spans.setdefault((section, key), KeySpan(line, col))
                pending_key = key
                expect_key[-1] = False
    return spans


def _scan_yaml_spans(text: str) -> dict[tuple[str, str], KeySpan]:
    """(section, key) → position for YAML, from PyYAML's event stream —
    every event carries start_mark, so spans are exact. `section` is
    the dotted map path, matching how key tables are keyed. Sequence
    members are not addressable at v1 (same as TOML arrays)."""
    import yaml

    spans: dict[tuple[str, str], KeySpan] = {}
    try:
        events = list(yaml.parse(text))
    except yaml.YAMLError:
        return spans
    path: list[str] = []
    expect_key: list[bool] = []  # per open mapping: next scalar is a key
    seq_depth = 0  # inside a sequence value — members are not keys
    pending_section_key: tuple[str, object] | None = None
    for ev in events:
        if isinstance(ev, yaml.events.SequenceStartEvent):
            seq_depth += 1
            pending_section_key = None
        elif isinstance(ev, yaml.events.SequenceEndEvent):
            seq_depth -= 1
            if seq_depth == 0 and expect_key:
                expect_key[-1] = True  # the sequence was a value
        elif seq_depth > 0:
            continue
        elif isinstance(ev, yaml.events.MappingStartEvent):
            if pending_section_key is not None:
                key, mark = pending_section_key
                path.append(key)
                section = ".".join(path)
                spans.setdefault(
                    (SECTION, section), KeySpan(mark.line + 1, mark.column + 1)
                )
                pending_section_key = None
            expect_key.append(True)
        elif isinstance(ev, yaml.events.MappingEndEvent):
            expect_key.pop()
            if path:
                path.pop()
            if expect_key:
                expect_key[-1] = True  # the map was a value
        elif isinstance(ev, yaml.events.ScalarEvent) and expect_key:
            if expect_key[-1]:
                section = ".".join(path)
                mark = ev.start_mark
                spans.setdefault(
                    (section, ev.value), KeySpan(mark.line + 1, mark.column + 1)
                )
                pending_section_key = (ev.value, mark)
                expect_key[-1] = False
            else:
                expect_key[-1] = True
    return spans


@dataclass
class Document:
    path: str
    text: str
    data: dict[str, Any]
    spans: dict[tuple[str, str], KeySpan]

    def label(self, section: str, key: str) -> list[dict[str, Any]]:
        s = self.spans.get((section, key))
        return [label(self.path, s.line, "", s.col)] if s else [label(self.path, 1, "")]

    @classmethod
    def parse_toml(cls, path: str, text: str) -> Document | Diagnostic:
        try:
            data = tomllib.loads(text)
        except tomllib.TOMLDecodeError as e:
            line, col = _toml_error_span(str(e))
            return Diagnostic(
                "A00",
                "error",
                f"invalid TOML: {e}",
                [label(path, line, "parse stops here", col)],
            )
        return cls(path=path, text=text, data=data, spans=_scan_spans(text))

    @classmethod
    def parse_yaml(cls, path: str, text: str) -> Document | Diagnostic:
        import yaml

        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as e:
            mark = getattr(e, "problem_mark", None)
            line, col = (mark.line + 1, mark.column + 1) if mark else (1, 1)
            return Diagnostic(
                "A00",
                "error",
                f"invalid YAML: {e}",
                [label(path, line, "parse stops here", col)],
            )
        if not isinstance(data, dict):
            return Diagnostic(
                "A00",
                "error",
                "top level of a config file must be a mapping",
                [label(path, 1, "")],
            )
        return cls(path=path, text=text, data=data, spans=_scan_yaml_spans(text))

    @classmethod
    def parse_json(cls, path: str, text: str) -> Document | Diagnostic:
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            return Diagnostic(
                "A00",
                "error",
                f"invalid JSON: {e}",
                [label(path, e.lineno, "parse stops here", e.colno)],
            )
        if not isinstance(data, dict):
            return Diagnostic(
                "A00",
                "error",
                "top level of a config file must be an object",
                [label(path, 1, "")],
            )
        return cls(path=path, text=text, data=data, spans=_scan_json_spans(text))
