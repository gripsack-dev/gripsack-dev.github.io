"""Linter assembly: the pipeline a tool package declares.

A linter is four honest pieces:

    handles        which basenames it lints (unknown files are ignored)
    resolve_table  tool_version → (key table, coverage warning | None)
    checks         ordered passes over the parsed Document — the table
                   engine first, tool-specific semantic checks after
    name           the tool name, for codespacing

Pure functions and plain lists — no registries, no decorators. One
check = one small function = one reviewable PR.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import dataclass, field

from .checks import Check, Table, table_check
from .document import Document
from .protocol import Diagnostic, serve

#: (tool_version, basename) → (table, coverage warning or None).
#: Tools with several config files (yazi.toml/keymap.toml/theme.toml)
#: dispatch on basename. Linters without key tables use `no_tables`.
TableResolver = Callable[..., tuple[Table | None, Diagnostic | None]]


def no_tables(tool_version: str | None, basename: str = "") -> tuple[None, None]:
    return None, None


@dataclass
class Linter:
    name: str
    #: Basenames this linter understands, e.g. {"config.toml"}.
    handles: set[str]
    resolve_table: TableResolver = no_tables
    #: Document parser for the config format (TOML by default).
    parse: Callable[[str, str], Document | Diagnostic] = Document.parse_toml
    #: Tool-specific passes, run after the table engine.
    checks: list[Check] = field(default_factory=list)
    #: Basenames linted leniently (shared files like pyproject.toml):
    #: unknown keys/sections are ignored, known paths still checked.
    lenient_basenames: set[str] = field(default_factory=set)

    def lint_file(self, path: str, text: str, tool_version: str | None) -> list[Diagnostic]:
        if os.path.basename(path) not in self.handles:
            return []
        parsed = self.parse(path, text)
        if isinstance(parsed, Diagnostic):
            return [parsed]
        table, warning = self.resolve_table(tool_version, os.path.basename(path))
        out: list[Diagnostic] = [warning] if warning else []
        if table is not None:
            strict = os.path.basename(path) not in self.lenient_basenames
            out.extend(table_check(parsed, table, strict=strict))
        for check in self.checks:
            out.extend(check(parsed, table))
        return out


def serve_linter(linter: Linter) -> None:
    """Console-script entry: `griplint-<tool> = ...:main` calls this."""
    serve(linter.name, linter.lint_file)
