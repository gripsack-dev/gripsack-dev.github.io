"""Key-table validation over a Document: the generic engine pass.

Tables are hand-written data (griplint-py is a two-way door — rigor can
grow later): {section: {key: Rule} | FREE_FORM}. Sections marked
FREE_FORM skip key validation entirely (user-defined bindings,
language names, …).

Fixed codes (codespaced by the protocol host as griplint-<tool>/<code>):

    A00  invalid TOML (from Document.parse_toml)
    A01  unknown key          A04  wrong type
    A02  unknown section      A05  value outside choices
    A03  deprecated key (warning, carries the rename as help)
"""

from __future__ import annotations

import difflib
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Any

from .document import SECTION, Document
from .protocol import Diagnostic

#: Section value meaning "any keys allowed here" — e.g. helix [keys.*].
FREE_FORM = "FREE_FORM"

#: A key table: dotted section → rules or FREE_FORM; "" holds bare
#: top-level keys.
Table = dict[str, Any]

#: A check pass: pure function over the parsed document. Tool packages
#: compose their own beyond the table engine (see linter.py).
Check = Callable[[Document, Table | None], Iterable[Diagnostic]]


@dataclass(frozen=True)
class Rule:
    types: tuple[type, ...]
    choices: tuple[Any, ...] | None = None
    deprecated: str | None = None  # replacement key, if renamed


_TYPE_NAMES = {
    str: "string",
    int: "integer",
    bool: "boolean",
    float: "float",
    list: "array",
    dict: "table",
}


def _suggest(key: str, known: Iterable[str]) -> str | None:
    matches = difflib.get_close_matches(key, list(known), n=1, cutoff=0.7)
    return matches[0] if matches else None


def _check_key(doc: Document, table: Table, section: str, key: str, val: Any, rules: dict[str, Rule]) -> list[Diagnostic]:
    rule = rules.get(key)
    where = f"[{section}] " if section else ""
    here = doc.label(section, key)
    if rule == FREE_FORM:  # user-named map at root level — anything goes
        return []
    if rule is None:
        suggestion = _suggest(key, rules)
        return [
            Diagnostic(
                "A01",
                "error",
                f"unknown key {where}{key!r}",
                here,
                help=f"did you mean {suggestion!r}?" if suggestion else None,
            )
        ]
    if rule.deprecated is not None:
        return [
            Diagnostic(
                "A03",
                "warning",
                f"{where}{key!r} is deprecated",
                here,
                help=f"renamed to {rule.deprecated!r}",
            )
        ]
    if not isinstance(val, rule.types) or (isinstance(val, bool) and bool not in rule.types):
        want = " or ".join(_TYPE_NAMES[t] for t in rule.types)
        return [
            Diagnostic(
                "A04",
                "error",
                f"{where}{key!r} must be {want}, got {_TYPE_NAMES.get(type(val), type(val).__name__)}",
                here,
            )
        ]
    if rule.choices is not None and val not in rule.choices:
        return [
            Diagnostic(
                "A05",
                "error",
                f"{where}{key!r} must be one of {', '.join(map(repr, rule.choices))}, got {val!r}",
                here,
            )
        ]
    return []


def table_check(doc: Document, table: Table | None, strict: bool = True) -> list[Diagnostic]:
    """The engine pass: one traversal emitting A01–A05. Tool-specific
    checks (cross-key constraints, semantic rules) are separate passes
    appended to the linter's check list.

    `strict=False` is for shared files (pyproject.toml): unknown keys
    and sections are ignored — the linter validates only what it owns."""
    assert table is not None
    out: list[Diagnostic] = []

    def walk(section: str, mapping: dict[str, Any]) -> None:
        # sections reached only as a namespace prefix ([tool] in
        # pyproject.toml) own no keys — FREE_FORM descent
        rules = table.get(section, FREE_FORM)
        for key, val in mapping.items():
            sub = f"{section}.{key}" if section else key
            if isinstance(val, dict) and sub in table:
                if table[sub] != FREE_FORM:
                    walk(sub, val)
                continue
            if isinstance(val, dict) and any(t.startswith(sub + ".") for t in table):
                walk(sub, val)
                continue
            if rules == FREE_FORM:
                continue
            if strict:
                out.extend(_check_key(doc, table, section, key, val, rules))
            else:
                out.extend(
                    d for d in _check_key(doc, table, section, key, val, rules) if d.code != "A01"
                )

    for key, value in doc.data.items():
        if isinstance(value, dict) and key in table:
            if table[key] != FREE_FORM:
                walk(key, value)
            continue
        if isinstance(value, dict) and any(t.startswith(key + ".") for t in table):
            walk(key, value)
            continue
        if isinstance(value, dict):
            # a dict-valued bare key (declared in the "" table) is not a
            # section — check it before complaining (profiles = {...})
            bare = table.get("")
            if bare and bare != FREE_FORM and bare.get(key) is not None:
                out.extend(_check_key(doc, table, "", key, value, bare))
                continue
            if not strict:
                continue
            suggestion = _suggest(key, table)
            out.append(
                Diagnostic(
                    "A02",
                    "error",
                    f"unknown section [{key}]",
                    doc.label(SECTION, key),
                    help=f"did you mean [{suggestion}]?" if suggestion else None,
                )
            )
            continue
        bare = table.get("")
        if bare and bare != FREE_FORM:
            if strict:
                out.extend(_check_key(doc, table, "", key, value, bare))
            else:
                out.extend(
                    d for d in _check_key(doc, table, "", key, value, bare) if d.code != "A01"
                )
    return out
