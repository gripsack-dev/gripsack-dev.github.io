"""The griplint-* plugin protocol (gripsack plan/0009 §2, 0011 §3).

One JSON request line on stdin:

    {"op": "lint", "paths": ["/abs/a.toml", ...], "tool_version": "25.5.31" | null}

NDJSON messages on stdout: any number of

    {"type": "diagnostic", "diagnostic": {...}}

then exactly one

    {"type": "response", "id": 1, "result": {...}}

The core renders diagnostics; plugins only serialize. Death is never
silent: a plugin that exits without a response gets a synthesized
error core-side, and `serve` below makes per-file failures structured
instead of fatal.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field
from typing import Any

#: A lint function: (path, text, tool_version) → diagnostics.
LintFn = Callable[[str, str, str | None], Iterable["Diagnostic"]]


@dataclass
class Diagnostic:
    """The core's shared diagnostic shape (0009 §4) — serialized as-is."""

    code: str
    severity: str  # "error" | "warning"
    message: str
    labels: list[dict[str, Any]] = field(default_factory=list)
    help: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "code": self.code,
            "severity": self.severity,
            "message": self.message,
            "labels": self.labels,
        }
        if self.help is not None:
            out["help"] = self.help
        return out


def label(file: str, line: int, note: str, col: int | None = None) -> dict[str, Any]:
    span: dict[str, Any] = {"file": file, "line": line}
    if col is not None:
        span["col"] = col
    return {"span": span, "note": note}


def _emit(msg: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(msg) + "\n")
    sys.stdout.flush()


def serve(plugin: str, lint: LintFn) -> None:
    """Run one lint exchange and exit. `plugin` is the tool name used
    for codespacing — codes from `lint` are prefixed `griplint-<plugin>/`
    when they aren't already."""
    request = json.loads(sys.stdin.readline())
    if request.get("op") != "lint":
        _emit(
            {
                "type": "diagnostic",
                "diagnostic": Diagnostic(
                    f"griplint-{plugin}/E00",
                    "error",
                    f"unknown op {request.get('op')!r} — this plugin speaks op=lint",
                ).to_dict(),
            }
        )
        _emit({"type": "response", "id": 1, "result": {"linted": 0}})
        return
    tool_version = request.get("tool_version")
    linted = 0
    for path in request.get("paths", []):
        try:
            with open(path, encoding="utf-8") as f:
                text = f.read()
        except OSError:
            continue  # the frontend only sends existing files; be safe anyway
        linted += 1
        try:
            diagnostics = lint(path, text, tool_version)
        except Exception as e:  # noqa: BLE001 — crash containment: a buggy linter fails one file, not the eval
            diagnostics = [
                Diagnostic(
                    f"griplint-{plugin}/E99",
                    # crash class: evidence about the LINTER, never about
                    # the config — warning, so a broken linter can't
                    # block a deployment (review finding E)
                    "warning",
                    f"linter {plugin!r} crashed on {path} — the linter is broken, not the config: {e}",
                )
            ]
        for d in diagnostics:
            if not d.code.startswith("griplint-"):
                d.code = f"griplint-{plugin}/{d.code}"
            _emit({"type": "diagnostic", "diagnostic": d.to_dict()})
    _emit({"type": "response", "id": 1, "result": {"linted": linted}})


def iter_request_paths() -> Iterator[str]:  # pragma: no cover - convenience
    request = json.loads(sys.stdin.readline())
    yield from request.get("paths", [])
