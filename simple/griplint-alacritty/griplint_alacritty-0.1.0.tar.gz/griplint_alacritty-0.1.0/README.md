# griplint-alacritty

Config linter for [alacritty](https://alacritty.org) `alacritty.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
