"""griplint-alacritty pipeline: what we lint, with which tables and passes.

Only `alacritty.toml` is linted; unknown files are ignored, never
errors (0011 §4).
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="alacritty",
    handles={"alacritty.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
