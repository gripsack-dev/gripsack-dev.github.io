"""Table resolution: which key table a pinned tool_version gets.

Nearest-match with a coverage warning, never a hard failure — an
unknown version must not break eval (see the repo author skill).
"""

from __future__ import annotations

from griplint_common import Diagnostic, Table

from . import v0

#: The TOML config era — alacritty 0.13+ (YAML was dropped in 0.14).
SUPPORTED = ("0.",)


def resolve(tool_version: str | None, basename: str = "") -> tuple[Table, Diagnostic | None]:
    warning = None
    if tool_version and not tool_version.startswith(SUPPORTED):
        warning = Diagnostic(
            "W10",
            "warning",
            "key tables are written for TOML-era alacritty (0.13+); "
            f"this module pins {tool_version} — results may be stale",
        )
    return v0.TABLES, warning
