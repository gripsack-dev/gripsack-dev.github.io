"""Key tables for TOML-era alacritty (0.13+), `alacritty.toml`.

Source: https://alacritty.org/config-alacritty.html (the alacritty.5
man page), read 2026-08. Every section below cites its docs anchor in
a comment. `[env]` and `[colors]` are FREE_FORM — env vars are
user-defined, and the colors sub-schema is large (TODO(coverage):
tabulate colors.primary/normal/bright/dim/cursor/search/...).
Bindings are arrays of tables — the engine checks the array type, not
the entries.
"""

from griplint_common import FREE_FORM, Rule

_choice = lambda *xs: Rule((str,), choices=xs)
_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))
_num = Rule((float, int))  # TOML floats; users write `opacity = 1` as int
_table = Rule((dict,))
_table_or_str = Rule((dict, str))

GENERAL = {  # docs: GENERAL
    "import": _strs,
    "working_directory": _str,
    "live_config_reload": _bool,
    "ipc_socket": _bool,
}

WINDOW = {  # docs: WINDOW
    "dimensions": _table,
    "position": _table_or_str,
    "padding": _table,
    "dynamic_padding": _bool,
    "decorations": _choice("Full", "None", "Transparent", "Buttonless"),
    "opacity": _num,
    "blur": _bool,
    "startup_mode": _choice("Windowed", "Maximized", "Fullscreen", "SimpleFullscreen"),
    "title": _str,
    "dynamic_title": _bool,
    "class": _table,
    "decorations_theme_variant": _choice("Dark", "Light", "None"),
    "resize_increments": _bool,
    "option_as_alt": _choice("OnlyLeft", "OnlyRight", "Both", "None"),
    "level": _choice("Normal", "AlwaysOnTop"),
}

SCROLLING = {  # docs: SCROLLING
    "history": _int,
    "multiplier": _int,
}

FONT = {  # docs: FONT
    "normal": _table,
    "bold": _table,
    "italic": _table,
    "bold_italic": _table,
    "size": _num,
    "offset": _table,
    "glyph_offset": _table,
    "builtin_box_drawing": _bool,
}

BELL = {  # docs: BELL
    "animation": _choice(
        "Ease",
        "EaseOut",
        "EaseOutSine",
        "EaseOutQuad",
        "EaseOutCubic",
        "EaseOutQuart",
        "EaseOutQuint",
        "EaseOutExpo",
        "EaseOutCirc",
        "Linear",
    ),
    "duration": _int,
    "color": _str,
    "command": _table_or_str,
}

SELECTION = {  # docs: SELECTION
    "semantic_escape_chars": _str,
    "save_to_clipboard": _bool,
}

CURSOR = {  # docs: CURSOR
    "style": _table,
    "vi_mode_style": _table_or_str,
    "blink_interval": _int,
    "blink_timeout": _int,
    "unfocused_hollow": _bool,
    "thickness": _num,
}

TERMINAL = {  # docs: TERMINAL
    "shell": _table_or_str,
    "osc52": _choice("Disabled", "OnlyCopy", "OnlyPaste", "CopyPaste"),
}

MOUSE = {  # docs: MOUSE
    "hide_when_typing": _bool,
    "bindings": Rule((list,)),
}

HINTS = {  # docs: HINTS
    "alphabet": _str,
    "enabled": Rule((list,)),
}

KEYBOARD = {  # docs: KEYBOARD
    "bindings": Rule((list,)),
}

DEBUG = {  # docs: DEBUG
    "render_timer": _bool,
    "persistent_logging": _bool,
    "log_level": _str,
    "print_events": _bool,
    "highlight_damage": _bool,
    "prefer_egl": _bool,
}

TABLES = {
    "general": GENERAL,
    "env": FREE_FORM,
    "window": WINDOW,
    "scrolling": SCROLLING,
    "font": FONT,
    "colors": FREE_FORM,  # TODO(coverage): tabulate the colors sub-schema
    "bell": BELL,
    "selection": SELECTION,
    "cursor": CURSOR,
    "terminal": TERMINAL,
    "mouse": MOUSE,
    "hints": HINTS,
    "keyboard": KEYBOARD,
    "debug": DEBUG,
}
