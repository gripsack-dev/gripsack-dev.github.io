# griplint-starship

Config linter for [starship](https://starship.rs) `starship.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
