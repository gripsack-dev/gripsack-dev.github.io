"""griplint-starship pipeline: what we lint, with which tables and passes.

Only `starship.toml` is linted. Tables are generated from the
#  official config schema — one sub-table per module. `[palettes.*]`
#  user palettes are FREE_FORM.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="starship",
    handles={"starship.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
