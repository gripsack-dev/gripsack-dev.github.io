"""Key tables for starship 1.x, `starship.toml`.

Source: GENERATED from the official config schema
(github.com/starship/starship .github/config-schema.json, 2026-08) —
root keys plus one sub-table per module (117 sections). `[palettes]`
and `[profiles]` are user-defined: FREE_FORM.
"""

from griplint_common import FREE_FORM, Rule

ROOT = {
    "format": Rule((str,)),
    "right_format": Rule((str,)),
    "continuation_prompt": Rule((str,)),
    "scan_timeout": Rule((int,)),
    "command_timeout": Rule((int,)),
    "add_newline": Rule((bool,)),
    "follow_symlinks": Rule((bool,)),
    "palette": Rule((str,)),
}

AWS = {
    "disabled": Rule((bool,)),
    "expiration_symbol": Rule((str,)),
    "force_display": Rule((bool,)),
    "format": Rule((str,)),
    "profile_aliases": Rule((dict,)),
    "region_aliases": Rule((dict,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

AZURE = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "subscription_aliases": Rule((dict,)),
    "symbol": Rule((str,)),
}

BATTERY = {
    "charging_symbol": Rule((str,)),
    "disabled": Rule((bool,)),
    "discharging_symbol": Rule((str,)),
    "display": Rule((list,)),
    "empty_symbol": Rule((str,)),
    "format": Rule((str,)),
    "full_symbol": Rule((str,)),
    "unknown_symbol": Rule((str,)),
}

BUF = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

BUN = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

C = {
    "commands": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

CHARACTER = {
    "disabled": Rule((bool,)),
    "error_symbol": Rule((str,)),
    "format": Rule((str,)),
    "success_symbol": Rule((str,)),
    "vimcmd_replace_one_symbol": Rule((str,)),
    "vimcmd_replace_symbol": Rule((str,)),
    "vimcmd_symbol": Rule((str,)),
    "vimcmd_visual_symbol": Rule((str,)),
}

CLAUDE_CONTEXT = {
    "disabled": Rule((bool,)),
    "display": Rule((list,)),
    "format": Rule((str,)),
    "gauge_empty_symbol": Rule((str,)),
    "gauge_full_symbol": Rule((str,)),
    "gauge_partial_symbol": Rule((str,)),
    "gauge_width": Rule((int,)),
    "symbol": Rule((str,)),
}

CLAUDE_COST = {
    "disabled": Rule((bool,)),
    "display": Rule((list,)),
    "format": Rule((str,)),
    "symbol": Rule((str,)),
}

CLAUDE_MODEL = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "model_aliases": Rule((dict,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

CMAKE = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

CMD_DURATION = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "min_time": Rule((int,)),
    "min_time_to_notify": Rule((int,)),
    "notification_timeout": Rule((int, str,)),
    "show_milliseconds": Rule((bool,)),
    "show_notifications": Rule((bool,)),
    "style": Rule((str,)),
}

COBOL = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

CONDA = {
    "detect_env_vars": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "ignore_base": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
}

CONTAINER = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

CPP = {
    "commands": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

CRYSTAL = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

DAML = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

DART = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

DENO = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

DIRECTORY = {
    "before_repo_root_style": Rule((str,)),
    "disabled": Rule((bool,)),
    "fish_style_pwd_dir_length": Rule((int,)),
    "format": Rule((str,)),
    "home_symbol": Rule((str,)),
    "read_only": Rule((str,)),
    "read_only_style": Rule((str,)),
    "repo_root_format": Rule((str,)),
    "repo_root_style": Rule((str,)),
    "style": Rule((str,)),
    "substitutions": Rule((dict, list,)),
    "truncate_to_repo": Rule((bool,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
    "use_logical_path": Rule((bool,)),
    "use_os_path_sep": Rule((bool,)),
}

DIRENV = {
    "allowed_msg": Rule((str,)),
    "denied_msg": Rule((str,)),
    "detect_env_vars": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "loaded_msg": Rule((str,)),
    "not_allowed_msg": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "unloaded_msg": Rule((str,)),
}

DOCKER_CONTEXT = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "only_with_files": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

DOTNET = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "heuristic": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

ELIXIR = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

ELM = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

ERLANG = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

FENNEL = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

FILL = {
    "disabled": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

FORTRAN = {
    "commands": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

FOSSIL_BRANCH = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
}

FOSSIL_METRICS = {
    "added_style": Rule((str,)),
    "deleted_style": Rule((str,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "only_nonzero_diffs": Rule((bool,)),
}

GCLOUD = {
    "detect_env_vars": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "project_aliases": Rule((dict,)),
    "region_aliases": Rule((dict,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

GIT_BRANCH = {
    "always_show_remote": Rule((bool,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "ignore_bare_repo": Rule((bool,)),
    "ignore_branches": Rule((list,)),
    "only_attached": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
}

GIT_COMMIT = {
    "commit_hash_length": Rule((int,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "only_detached": Rule((bool,)),
    "style": Rule((str,)),
    "tag_disabled": Rule((bool,)),
    "tag_max_candidates": Rule((int,)),
    "tag_symbol": Rule((str,)),
}

GIT_METRICS = {
    "added_style": Rule((str,)),
    "deleted_style": Rule((str,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "ignore_submodules": Rule((bool,)),
    "only_nonzero_diffs": Rule((bool,)),
}

GIT_STATE = {
    "am": Rule((str,)),
    "am_or_rebase": Rule((str,)),
    "bisect": Rule((str,)),
    "cherry_pick": Rule((str,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "merge": Rule((str,)),
    "rebase": Rule((str,)),
    "revert": Rule((str,)),
    "style": Rule((str,)),
}

GIT_STATUS = {
    "ahead": Rule((str,)),
    "behind": Rule((str,)),
    "conflicted": Rule((str,)),
    "deleted": Rule((str,)),
    "disabled": Rule((bool,)),
    "diverged": Rule((str,)),
    "format": Rule((str,)),
    "ignore_submodules": Rule((bool,)),
    "index_added": Rule((str,)),
    "index_deleted": Rule((str,)),
    "index_modified": Rule((str,)),
    "index_typechanged": Rule((str,)),
    "modified": Rule((str,)),
    "renamed": Rule((str,)),
    "staged": Rule((str,)),
    "stashed": Rule((str,)),
    "style": Rule((str,)),
    "typechanged": Rule((str,)),
    "untracked": Rule((str,)),
    "up_to_date": Rule((str,)),
    "use_git_executable": Rule((bool,)),
    "windows_starship": Rule((str,)),
    "worktree_added": Rule((str,)),
    "worktree_deleted": Rule((str,)),
    "worktree_modified": Rule((str,)),
    "worktree_typechanged": Rule((str,)),
}

GLEAM = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

GOLANG = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "not_capable_style": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

GRADLE = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "recursive": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

GUIX_SHELL = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

HASKELL = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

HAXE = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

HELM = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

HG_BRANCH = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
}

HG_STATE = {
    "bisect": Rule((str,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "graft": Rule((str,)),
    "histedit": Rule((str,)),
    "merge": Rule((str,)),
    "rebase": Rule((str,)),
    "shelve": Rule((str,)),
    "style": Rule((str,)),
    "transplant": Rule((str,)),
    "update": Rule((str,)),
}

HOSTNAME = {
    "aliases": Rule((dict,)),
    "detect_env_vars": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "ssh_only": Rule((bool,)),
    "ssh_symbol": Rule((str,)),
    "style": Rule((str,)),
    "trim_at": Rule((str,)),
}

JAVA = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

JJ_BOOKMARK = {
    "disabled": Rule((bool,)),
    "diverged_symbol": Rule((str,)),
    "format": Rule((str,)),
    "ignore_names": Rule((list,)),
    "ignore_remotes": Rule((list,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
}

JOBS = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "number_threshold": Rule((int,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "symbol_threshold": Rule((int,)),
    "threshold": Rule((int,)),
}

JULIA = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

KOTLIN = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "kotlin_binary": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

KUBERNETES = {
    "context_aliases": Rule((dict,)),
    "contexts": Rule((list,)),
    "detect_env_vars": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "user_aliases": Rule((dict,)),
}

LINE_BREAK = {
    "disabled": Rule((bool,)),
}

LOCALIP = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "ssh_only": Rule((bool,)),
    "style": Rule((str,)),
}

LUA = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "lua_binary": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

MAVEN = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "recursive": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

MEMORY_USAGE = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "threshold": Rule((int,)),
}

MESON = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
}

MISE = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "healthy_symbol": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "unhealthy_symbol": Rule((str,)),
}

MOJO = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

NATS = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

NETNS = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

NIM = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

NIX_SHELL = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "heuristic": Rule((bool,)),
    "impure_msg": Rule((str,)),
    "pure_msg": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "unknown_msg": Rule((str,)),
}

NODEJS = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "not_capable_style": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

OCAML = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "global_switch_indicator": Rule((str,)),
    "local_switch_indicator": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

ODIN = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "show_commit": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

OPA = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

OPENSTACK = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

OS = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbols": Rule((dict,)),
}

PACKAGE = {
    "disabled": Rule((bool,)),
    "display_private": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

PERL = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

PHP = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

PIJUL_CHANNEL = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
    "truncation_symbol": Rule((str,)),
}

PIXI = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "pixi_binary": Rule((list, str,)),
    "show_default_environment": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

PULUMI = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "search_upwards": Rule((bool,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

PURESCRIPT = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

PYTHON = {
    "detect_env_vars": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "generic_venv_names": Rule((list,)),
    "pyenv_prefix": Rule((str,)),
    "pyenv_version_name": Rule((bool,)),
    "python_binary": Rule((list, str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

QUARTO = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

RAKU = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

RED = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

RLANG = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

RUBY = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "detect_variables": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

RUST = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

SCALA = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

SHELL = {
    "bash_indicator": Rule((str,)),
    "cmd_indicator": Rule((str,)),
    "disabled": Rule((bool,)),
    "elvish_indicator": Rule((str,)),
    "fish_indicator": Rule((str,)),
    "format": Rule((str,)),
    "ion_indicator": Rule((str,)),
    "nu_indicator": Rule((str,)),
    "powershell_indicator": Rule((str,)),
    "pwsh_indicator": Rule((str,)),
    "style": Rule((str,)),
    "tcsh_indicator": Rule((str,)),
    "unknown_indicator": Rule((str,)),
    "xonsh_indicator": Rule((str,)),
    "zsh_indicator": Rule((str,)),
}

SHLVL = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "repeat": Rule((bool,)),
    "repeat_offset": Rule((int,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "threshold": Rule((int,)),
}

SINGULARITY = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

SOLIDITY = {
    "compiler": Rule((list, str,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

SPACK = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "truncation_length": Rule((int,)),
}

STATUS = {
    "disabled": Rule((bool,)),
    "failure_style": Rule((str,)),
    "format": Rule((str,)),
    "map_symbol": Rule((bool,)),
    "not_executable_symbol": Rule((str,)),
    "not_found_symbol": Rule((str,)),
    "pipestatus": Rule((bool,)),
    "pipestatus_format": Rule((str,)),
    "pipestatus_segment_format": Rule((str,)),
    "pipestatus_separator": Rule((str,)),
    "recognize_signal_code": Rule((bool,)),
    "sigint_symbol": Rule((str,)),
    "signal_symbol": Rule((str,)),
    "style": Rule((str,)),
    "success_style": Rule((str,)),
    "success_symbol": Rule((str,)),
    "symbol": Rule((str,)),
}

SUDO = {
    "allow_windows": Rule((bool,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "use_legacy_check": Rule((bool,)),
}

SWIFT = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

TERRAFORM = {
    "commands": Rule((list,)),
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

TIME = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "time_format": Rule((str,)),
    "time_range": Rule((str,)),
    "use_12hr": Rule((bool,)),
    "utc_time_offset": Rule((str,)),
}

TYPST = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

USERNAME = {
    "aliases": Rule((dict,)),
    "detect_env_vars": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "show_always": Rule((bool,)),
    "style_root": Rule((str,)),
    "style_user": Rule((str,)),
}

VAGRANT = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

VCS = {
    "disabled": Rule((bool,)),
    "fossil_modules": Rule((str,)),
    "git_modules": Rule((str,)),
    "hg_modules": Rule((str,)),
    "order": Rule((list,)),
    "pijul_modules": Rule((str,)),
}

VCSH = {
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
}

VLANG = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

XMAKE = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

ZIG = {
    "detect_extensions": Rule((list,)),
    "detect_files": Rule((list,)),
    "detect_folders": Rule((list,)),
    "disabled": Rule((bool,)),
    "format": Rule((str,)),
    "style": Rule((str,)),
    "symbol": Rule((str,)),
    "version_format": Rule((str,)),
}

TABLES = {
    "": ROOT,
    "palettes": FREE_FORM,
    "profiles": FREE_FORM,
    "aws": AWS,
    "azure": AZURE,
    "battery": BATTERY,
    "buf": BUF,
    "bun": BUN,
    "c": C,
    "character": CHARACTER,
    "claude_context": CLAUDE_CONTEXT,
    "claude_cost": CLAUDE_COST,
    "claude_model": CLAUDE_MODEL,
    "cmake": CMAKE,
    "cmd_duration": CMD_DURATION,
    "cobol": COBOL,
    "conda": CONDA,
    "container": CONTAINER,
    "cpp": CPP,
    "crystal": CRYSTAL,
    "daml": DAML,
    "dart": DART,
    "deno": DENO,
    "directory": DIRECTORY,
    "direnv": DIRENV,
    "docker_context": DOCKER_CONTEXT,
    "dotnet": DOTNET,
    "elixir": ELIXIR,
    "elm": ELM,
    "env_var": FREE_FORM,
    "erlang": ERLANG,
    "fennel": FENNEL,
    "fill": FILL,
    "fortran": FORTRAN,
    "fossil_branch": FOSSIL_BRANCH,
    "fossil_metrics": FOSSIL_METRICS,
    "gcloud": GCLOUD,
    "git_branch": GIT_BRANCH,
    "git_commit": GIT_COMMIT,
    "git_metrics": GIT_METRICS,
    "git_state": GIT_STATE,
    "git_status": GIT_STATUS,
    "gleam": GLEAM,
    "golang": GOLANG,
    "gradle": GRADLE,
    "guix_shell": GUIX_SHELL,
    "haskell": HASKELL,
    "haxe": HAXE,
    "helm": HELM,
    "hg_branch": HG_BRANCH,
    "hg_state": HG_STATE,
    "hostname": HOSTNAME,
    "java": JAVA,
    "jj_bookmark": JJ_BOOKMARK,
    "jobs": JOBS,
    "julia": JULIA,
    "kotlin": KOTLIN,
    "kubernetes": KUBERNETES,
    "line_break": LINE_BREAK,
    "localip": LOCALIP,
    "lua": LUA,
    "maven": MAVEN,
    "memory_usage": MEMORY_USAGE,
    "meson": MESON,
    "mise": MISE,
    "mojo": MOJO,
    "nats": NATS,
    "netns": NETNS,
    "nim": NIM,
    "nix_shell": NIX_SHELL,
    "nodejs": NODEJS,
    "ocaml": OCAML,
    "odin": ODIN,
    "opa": OPA,
    "openstack": OPENSTACK,
    "os": OS,
    "package": PACKAGE,
    "perl": PERL,
    "php": PHP,
    "pijul_channel": PIJUL_CHANNEL,
    "pixi": PIXI,
    "pulumi": PULUMI,
    "purescript": PURESCRIPT,
    "python": PYTHON,
    "quarto": QUARTO,
    "raku": RAKU,
    "red": RED,
    "rlang": RLANG,
    "ruby": RUBY,
    "rust": RUST,
    "scala": SCALA,
    "shell": SHELL,
    "shlvl": SHLVL,
    "singularity": SINGULARITY,
    "solidity": SOLIDITY,
    "spack": SPACK,
    "status": STATUS,
    "sudo": SUDO,
    "swift": SWIFT,
    "terraform": TERRAFORM,
    "time": TIME,
    "typst": TYPST,
    "username": USERNAME,
    "vagrant": VAGRANT,
    "vcs": VCS,
    "vcsh": VCSH,
    "vlang": VLANG,
    "xmake": XMAKE,
    "zig": ZIG,
    "custom": FREE_FORM,
}
