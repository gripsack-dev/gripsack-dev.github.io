"""Key tables for atuin 18.x, `config.toml`.

Source: crates/atuin-client/src/settings.rs in atuinsh/atuin (the
authoritative serde struct, incl. `search_mode` renames), cross-checked
with docs.atuin.sh/configuration/config. Enum choices from the serde
variant renames. Sections whose values are HashMaps (user-defined
bindings) and the fast-moving [ai] surface are FREE_FORM.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_num = Rule((int, float))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))

FILTER_MODES = ("global", "host", "session", "directory", "workspace", "session-preload")

#: bare top-level keys — source: Settings struct (renames applied)
ROOT = {
    "data_dir": _str,
    "dialect": Rule((str,), choices=("us", "uk")),
    "timezone": _str,
    "style": Rule((str,), choices=("auto", "full", "compact")),
    "auto_sync": _bool,
    "update_check": _bool,
    "update_channel": Rule((str,), choices=("stable", "nightly")),
    "sync_address": _str,
    "sync_protocol": _str,
    "sync_frequency": _str,
    "db_path": _str,
    "record_store_path": _str,
    "key_path": _str,
    "session_path": _str,
    "search_mode": Rule((str,), choices=("prefix", "fulltext", "fuzzy", "daemon-fuzzy")),
    "filter_mode": Rule((str,), choices=FILTER_MODES),
    "filter_mode_shell_up_key_binding": Rule((str,), choices=FILTER_MODES),
    "search_mode_shell_up_key_binding": Rule(
        (str,), choices=("prefix", "fulltext", "fuzzy", "daemon-fuzzy")
    ),
    "shell_up_key_binding": _bool,
    "inline_height": _int,
    "inline_height_shell_up_key_binding": _int,
    "invert": _bool,
    "show_preview": _bool,
    "max_preview_height": _int,
    "show_help": _bool,
    "show_tabs": _bool,
    "show_numeric_shortcuts": _bool,
    "auto_hide_height": _int,
    "exit_mode": Rule((str,), choices=("return-original", "return-query")),
    "keymap_mode": _str,
    "keymap_mode_shell": _str,
    "keymap_cursor": _table,
    "word_jump_mode": _str,
    "word_chars": _str,
    "scroll_context_lines": _int,
    "history_format": _str,
    "strip_trailing_whitespace": _bool,
    "prefers_reduced_motion": _bool,
    "store_failed": _bool,
    "no_mouse": _bool,
    "history_filter": _strs,
    "cwd_filter": _strs,
    "secrets_filter": _bool,
    "workspaces": _bool,
    "ctrl_n_shortcuts": _bool,
    "network_connect_timeout": _int,
    "network_timeout": _int,
    "local_timeout": _num,
    "extra_headers": _table,
    "enter_accept": _bool,
    "smart_sort": _bool,
    "command_chaining": _bool,
}

STATS = {  # source: Stats struct
    "common_prefix": _strs,
    "common_subcommands": _strs,
    "ignored_commands": _strs,
}

KEYS = {  # source: Keys struct
    "scroll_exits": _bool,
    "exit_past_line_start": _bool,
    "accept_past_line_end": _bool,
    "accept_past_line_start": _bool,
    "accept_with_backspace": _bool,
    "prefix": _str,
}

PREVIEW = {  # source: Preview struct
    "strategy": _str,
}

DAEMON = {  # docs: [daemon]
    "enabled": _bool,
    "socket_path": _str,
    "pidfile_path": _str,
    "autostart": _bool,
}

PTY_PROXY = {  # source: PtyProxy struct
    "enabled": _bool,
}

SEARCH = {  # source: Search struct — score multipliers
    "filters": _strs,
    "recency_score_multiplier": _num,
    "frequency_score_multiplier": _num,
    "frecency_score_multiplier": _num,
    "shells": _table,  # per-shell tuning, type-checked only
}

THEME = {  # source: Theme struct
    "name": _str,
    "debug": _bool,
    "max_depth": _int,
}

UI = {  # source: Ui struct
    "columns": _strs,
    "syntax_highlight": _bool,
}

TMUX = {  # source: Tmux struct
    "enabled": _bool,
    "width": _str,
    "height": _str,
}

LOGS = {  # source: Logs struct — per-facility tables type-checked only
    "enabled": _bool,
    "dir": _str,
    "level": _str,
    "retention": _int,
    "search": _table,
    "daemon": _table,
    "ai": _table,
}

TABLES = {
    "": ROOT,
    "stats": STATS,
    "keys": KEYS,
    "keymap": FREE_FORM,  # HashMaps of user-defined bindings
    "preview": PREVIEW,
    "dotfiles": _table,  # enable/disable only — type-checked
    "daemon": DAEMON,
    "pty_proxy": PTY_PROXY,
    "search": SEARCH,
    "theme": THEME,
    "ui": UI,
    "scripts": FREE_FORM,
    "kv": FREE_FORM,
    "tmux": TMUX,
    "logs": LOGS,
    "ai": FREE_FORM,  # TODO(coverage): fast-moving feature surface
}
