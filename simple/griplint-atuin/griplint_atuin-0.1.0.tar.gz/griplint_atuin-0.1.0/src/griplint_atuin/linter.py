"""griplint-atuin pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. `[keymap]`/HashMap sections and the `[ai]`
#  surface are FREE_FORM — user-defined bindings and a fast-moving feature
#  area (TODO(coverage): tabulate ai). Unknown files are ignored.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="atuin",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
