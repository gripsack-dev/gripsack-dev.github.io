"""griplint-helix tests: behavior is pinned by fixtures
(input config → expected diagnostics); unit tests cover what fixtures
can't (pipeline composition, harness invariants)."""

from pathlib import Path

import pytest
from griplint_common.fixtures import check_fixtures, iter_cases, run_case
from griplint_helix.linter import LINTER

FIXTURES = Path(__file__).parent / "fixtures"


def test_fixtures():
    check_fixtures(LINTER, FIXTURES)


@pytest.mark.parametrize("case", sorted(iter_cases(FIXTURES)), ids=lambda c: c.name)
def test_case(case):
    assert run_case(LINTER, case) == []


def test_unknown_files_are_ignored():
    assert LINTER.lint_file("/c/random.txt", "BAD", None) == []
