"""Table resolution: which key table a pinned tool_version gets.

Nearest-match with a coverage warning, never a hard failure — an
unknown version must not break eval, or every helix release teaches
people to disable linting.
"""

from __future__ import annotations

from griplint_common import Diagnostic, Table

from . import v25

#: Tool-version prefixes our tables are current against.
SUPPORTED = ("25.",)


def resolve(tool_version: str | None, basename: str = "") -> tuple[Table, Diagnostic | None]:
    warning = None
    if tool_version and not tool_version.startswith(SUPPORTED):
        warning = Diagnostic(
            "W10",
            "warning",
            "key tables are written for helix 25.x; "
            f"this module pins {tool_version} — results may be stale",
        )
    return v25.TABLES, warning
