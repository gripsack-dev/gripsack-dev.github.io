"""Key tables for helix 25.x (`config.toml`).

Pure data — the shape of a valid config as hand-written rules. Review
this file when helix releases; the diff *is* the changelog review.
`[keys.*]` is FREE_FORM: bindings are user-defined by nature.
"""

from griplint_common import FREE_FORM, Rule

_choice = lambda *xs: Rule((str,), choices=xs)
_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))

EDITOR = {
    "scrolloff": _int,
    "mouse": _bool,
    "middle-click-paste": _bool,
    "scroll-lines": _int,
    "shell": _strs,
    "line-number": _choice("absolute", "relative"),
    "cursorline": _bool,
    "cursorcolumn": _bool,
    "gutters": _strs,
    "auto-completion": _bool,
    "auto-format": _bool,
    "auto-save": _bool,
    "idle-timeout": _int,
    "completion-trigger-len": _int,
    "completion-replace": _bool,
    "auto-info": _bool,
    "true-color": _bool,
    "rulers": _strs,
    "bufferline": _choice("always", "never", "multiple"),
    "color-modes": _bool,
    "popup-border": _choice("none", "all", "popup", "menu"),
    "border": _bool,
    "insert-final-newline": _bool,
    "trim-final-newlines": _bool,
    "trim-trailing-whitespace": _bool,
    "hidden": _bool,
    "wrap-indicator": _str,
    "jump-label-alphabet": _str,
}

CURSOR_SHAPE = {
    "normal": _choice("block", "bar", "underline", "hidden"),
    "insert": _choice("block", "bar", "underline", "hidden"),
    "select": _choice("block", "bar", "underline", "hidden"),
}

INDENT_GUIDES = {
    "render": _bool,
    "character": _str,
    "skip-levels": _int,
}

SOFT_WRAP = {
    "enable": _bool,
    "max-wrap": _int,
    "max-indent-retain": _int,
    "wrap-indicator": _str,
    "wrap-at-text-width": _bool,
}

STATUSLINE = {
    "left": _strs,
    "center": _strs,
    "right": _strs,
    "separator": _str,
    "mode": FREE_FORM,
}

FILE_PICKER = {
    "hidden": _bool,
    "follow-symlinks": _bool,
    "git-ignore": _bool,
    "git-global": _bool,
    "git-exclude": _bool,
    "ignore": _bool,
}

TABLES = {
    "": {"theme": _str},
    "editor": EDITOR,
    "editor.cursor-shape": CURSOR_SHAPE,
    "editor.indent-guides": INDENT_GUIDES,
    "editor.soft-wrap": SOFT_WRAP,
    "editor.statusline": STATUSLINE,
    "editor.file-picker": FILE_PICKER,
    "keys": FREE_FORM,
}
