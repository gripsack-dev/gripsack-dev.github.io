"""griplint-helix pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. `languages.toml` is skipped — its keys
are language names (user-defined by nature), a richer schema than a
key table can honestly cover. Unknown files are ignored, never errors
(0011 §4).
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="helix",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],  # no helix-specific semantic passes yet
)
