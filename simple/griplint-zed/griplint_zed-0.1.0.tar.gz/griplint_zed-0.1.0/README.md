# griplint-zed

Config linter for [zed](https://zed.dev) `settings.json` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [linters-py repo](https://github.com/gripsack-dev/linters-py) for usage.
