"""griplint-zed pipeline: what we lint, with which tables and passes.

Both `settings.json` and `keymap.json`... keymap needs array-member\n# linting (v2). settings.json only at v1. Tables derived from zed's\n# shipped assets/settings/default.json; sub-objects are type-checked.
"""

from griplint_common import Document, Linter

from . import tables

LINTER = Linter(
    name="zed",
    handles={"settings.json"},
    resolve_table=tables.resolve,
    parse=Document.parse_json,
    checks=[],
)
