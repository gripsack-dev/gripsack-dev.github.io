"""griplint-harlequin pipeline: what we lint, with which tables and passes.

Only `harlequin.toml` is linted. Config can also live in pyproject.toml
#  `[tool.harlequin]` — that needs section extraction in the engine
#  (TODO: shared with griplint-ruff). Profiles are adapter-driven open
#  maps: type-checked only.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="harlequin",
    handles={"harlequin.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
