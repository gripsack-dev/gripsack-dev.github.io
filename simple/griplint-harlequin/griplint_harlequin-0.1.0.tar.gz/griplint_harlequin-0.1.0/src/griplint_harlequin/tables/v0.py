"""Key tables for harlequin 1.x/2.x, `harlequin.toml`.

Source: src/harlequin/config.py in tconbeer/harlequin (the msgspec
Config struct, read 2026-08): `default_profile`, `profiles`,
`keymaps` are the only fixed keys. Profile bodies are adapter-driven
open maps (`Profile = Dict[str, Any]` — valid keys come from the CLI
and adapters), so they're type-checked only. `keymaps` is a user
binding map.
"""

from griplint_common import Rule

_str = Rule((str,))
_table = Rule((dict,))

#: bare top-level keys — source: Config struct
ROOT = {
    "default_profile": _str,
    "profiles": _table,  # adapter-driven open maps per profile name
    "keymaps": _table,  # user-defined key bindings
}

TABLES = {
    "": ROOT,
}
