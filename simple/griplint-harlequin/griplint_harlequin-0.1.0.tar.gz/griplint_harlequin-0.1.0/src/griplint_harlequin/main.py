"""griplint-harlequin — config linter for harlequin (https://harlequin.sh)."""

from griplint_common import serve_linter

from .linter import LINTER


def main() -> None:
    serve_linter(LINTER)


if __name__ == "__main__":
    main()
