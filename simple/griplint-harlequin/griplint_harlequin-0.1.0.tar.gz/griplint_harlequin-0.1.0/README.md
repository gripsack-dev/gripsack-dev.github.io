# griplint-harlequin

Config linter for [harlequin](https://harlequin.sh) `harlequin.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
