"""Key tables for rio 0.2.x, `config.toml`.

Source: rio-backend/src/config/*.rs in raphamorim/rio (the serde
structs — mod.rs Config plus window/navigation/renderer/bell/hints/
keyboard/title/shell/scroll/developer/cursor), read 2026-08.
`[colors]` and `[[bindings]]` are FREE_FORM; fonts/margin/panel/
effects/platform/adaptive_* sub-tables are type-checked only
(TODO(coverage): tabulate them).
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_num = Rule((int, float))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))

CURSOR = {  # source: CursorConfig (mod.rs)
    "shape": _str,
    "blinking": _bool,
    "blinking_interval": _int,
}

SHELL = {  # source: Shell (mod.rs)
    "program": _str,
    "args": _strs,
}

SCROLL = {  # source: Scroll (mod.rs)
    "multiplier": _num,
    "divider": _num,
}

DEVELOPER = {  # source: Developer (mod.rs)
    "enable_fps_counter": _bool,
    "log_level": _str,
    "enable_log_file": _bool,
}

WINDOW = {  # source: config/window.rs
    "width": _int,
    "height": _int,
    "mode": _str,
    "opacity": _num,
    "opacity_cells": _bool,
    "blur": _table,
    "background_image": _table,
    "decorations": _str,
    "macos_use_unified_titlebar": _bool,
    "macos_use_shadow": _bool,
    "macos_traffic_light_position_x": _num,
    "macos_traffic_light_position_y": _num,
    "initial_title": _str,
    "windows_use_undecorated_shadow": _bool,
    "windows_use_no_redirection_bitmap": _bool,
    "windows_corner_preference": _str,
    "colorspace": _str,
    "columns": _int,
    "rows": _int,
    "quake_width_percentage": _num,
}

NAVIGATION = {  # source: config/navigation.rs
    "program": _str,
    "path": _str,
    "color": _strs,
    "mode": _str,
    "color_automation": _strs,
    "clickable": _bool,
    "current_working_directory": _bool,
    "use_terminal_title": _bool,
    "hide_if_single": _bool,
    "use_split": _bool,
    "open_config_with_split": _bool,
    "unfocused_split_opacity": _num,
    "unfocused_split_fill": _strs,
    "max_tab_width": _num,
}

RENDERER = {  # source: config/renderer.rs
    "backend": _str,
    "disable_unfocused_render": _bool,
    "disable_occluded_render": _bool,
    "filters": _strs,
    "strategy": _str,
    "use_cpu": _bool,
}

BELL = {  # source: config/bell.rs
    "audio": _bool,
}

HINTS = {  # source: config/hints.rs
    "alphabet": _str,
    "rules": _strs,
    "regex": _str,
    "hyperlinks": _bool,
    "post_processing": _bool,
    "persist": _bool,
    "action": _str,
    "mouse": _table,
    "binding": _table,
    "enabled": _bool,
    "mods": _strs,
    "key": _str,
    "mode": _strs,
}

KEYBOARD = {  # source: config/keyboard.rs
    "disable_ctlseqs_alt": _bool,
    "ime_cursor_positioning": _bool,
    "forward_to_ime_modifier_mask": _strs,
}

TITLE = {  # source: config/title.rs
    "placeholder": _str,
    "content": _str,
}

#: bare top-level keys — source: Config struct (mod.rs)
ROOT = {
    "use_fork": _bool,
    "working_dir": _str,
    "line_height": _num,
    "theme": _str,
    "env_vars": _strs,
    "option_as_alt": _str,
    "force_theme": _str,
    "ignore_selection_fg_color": _bool,
    "confirm_before_quit": _bool,
    "grapheme_clustering": _bool,
    "copy_on_select": _bool,
    "hide_cursor_when_typing": _bool,
    "draw_bold_text_with_light_colors": _bool,
    "enable_scroll_bar": _bool,
    "scrollback_history_limit": _int,
    "bindings": Rule((list,)),  # [[bindings]] — entries are user bindings
}

TABLES = {
    "": ROOT,
    "cursor": CURSOR,
    "shell": SHELL,
    "editor": SHELL,  # same shape (source: editor: Shell)
    "scroll": SCROLL,
    "developer": DEVELOPER,
    "window": WINDOW,
    "navigation": NAVIGATION,
    "renderer": RENDERER,
    "bell": BELL,
    "hints": HINTS,
    "keyboard": KEYBOARD,
    "title": TITLE,
    "platform": _table,
    "fonts": _table,
    "margin": _table,
    "panel": _table,
    "effects": _table,
    "adaptive_theme": _table,
    "adaptive_colors": _table,
    "colors": FREE_FORM,  # TODO(coverage): color palette keys
    "bindings": FREE_FORM,  # user key bindings
}
