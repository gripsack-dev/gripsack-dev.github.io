"""griplint-rio pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. `[colors]` and `[[bindings]]` are
#  FREE_FORM (color palettes, user bindings); complex sub-tables
#  (fonts/effects/margin/panel) are type-checked only at v1.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="rio",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
