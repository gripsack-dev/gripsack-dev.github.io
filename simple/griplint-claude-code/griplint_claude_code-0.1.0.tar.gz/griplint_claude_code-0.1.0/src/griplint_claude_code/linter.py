"""griplint-claude-code pipeline: what we lint, with which tables and passes.

Both `settings.json` and `settings.local.json` are linted (same schema).\n# Tables are generated from the official SchemaStore schema. `env` and\n# other user-keyed maps are FREE_FORM.
"""

from griplint_common import Document, Linter

from . import tables

LINTER = Linter(
    name="claude-code",
    handles={"settings.json", "settings.local.json"},
    resolve_table=tables.resolve,
    parse=Document.parse_json,
    checks=[],
)
