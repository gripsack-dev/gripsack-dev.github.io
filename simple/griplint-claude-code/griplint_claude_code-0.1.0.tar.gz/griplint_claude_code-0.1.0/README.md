# griplint-claude-code

Config linter for [claude code](https://code.claude.com) `settings.json` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [linters-py repo](https://github.com/gripsack-dev/linters-py) for usage.
