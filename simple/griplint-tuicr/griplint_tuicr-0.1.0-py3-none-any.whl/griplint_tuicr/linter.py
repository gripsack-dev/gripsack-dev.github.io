"""griplint-tuicr pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. `comment_types` entries and custom\n# themes (themes/*.toml) are user-defined: FREE_FORM/array-typed.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="tuicr",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
