"""Key tables for tuicr 1.x, `config.toml`.

Source: github.com/agavra/tuicr docs/CONFIG.md "Options" + the full
example (read 2026-08). Flat config — all keys bare top-level.
`comment_types` is a user-defined array; export section keys from the
reference (intro/legend/headers).
"""

from griplint_common import Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))

#: bare top-level keys — docs/CONFIG.md Options table
ROOT = {
    "theme": _str,
    "appearance": Rule((str,), choices=("system", "dark", "light")),
    "theme_dark": _str,
    "theme_light": _str,
    "diff_view": Rule((str,), choices=("unified", "side-by-side")),
    "commit_order": Rule((str,), choices=("descending", "ascending")),
    "initial_commit_selection": Rule((str,), choices=("all", "oldest")),
    "ignore_whitespace": _bool,
    "show_file_list": _bool,
    "show_pr_checks": _bool,
    "show_pr_comments": _bool,
    "show_commits": _bool,
    "show_reviewed": _bool,
    "mouse": _bool,
    "leader": _str,
    "comment_vim": _bool,
    "comment_tab_width": _int,
    "wrap": _bool,
    "relative_line_numbers": _bool,
    "cursor_line": _bool,
    "search_highlight": _bool,
    "transparent_background": _bool,
    "scroll_offset": _int,
    "no_update_check": _bool,
    "review_watch_interval_ms": _int,
    "single_file_view": _bool,
    "username": _str,
    "diff_watch_interval_ms": _int,
    "backend": Rule((str,), choices=("libgit2", "cli")),
    "comment_types": _strs,
    "comment_type_prefix": _bool,
    "export_legend": _bool,
    # export section (docs: Export)
    "intro": _str,
    "scope_line": _bool,
    "pr_metadata": _bool,
    "comments_header": _str,
    "remote_comments_header": _str,
    "legend": _bool,
}

TABLES = {
    "": ROOT,
}
