# griplint-tuicr

Config linter for [tuicr](https://github.com/agavra/tuicr) `config.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [linters-py repo](https://github.com/gripsack-dev/linters-py) for usage.
