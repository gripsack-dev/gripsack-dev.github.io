"""griplint-broot pipeline: what we lint, with which tables and passes.

Only `conf.toml` is linted (HJSON variant is out of scope at v1 per the
#  issue). Map keys (special_paths/ext_colors/search-modes/skin) are
#  user-named: type-checked only. `verbs` and `preview_transformers`
#  are user-defined arrays.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="broot",
    handles={"conf.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
