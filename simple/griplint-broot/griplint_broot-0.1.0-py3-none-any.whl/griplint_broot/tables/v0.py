"""Key tables for broot 1.x, `conf.toml`.

Source: dystroy.org/broot/conf_file (read 2026-08) — the full settings
reference. The config is flat (all keys bare top-level). Map keys
whose names are user-chosen (special_paths, ext_colors, search-modes,
skin) are type-checked only; `verbs` and `preview_transformers` are
user-defined arrays.
"""

from griplint_common import Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))

#: bare top-level keys — docs: conf_file reference
ROOT = {
    "default_flags": _str,
    "show_selection_mark": _bool,
    "cols_order": Rule(
        (list,),
        # each entry: mark, git, branch, permission, date, size, count, name
    ),
    "syntax_theme": Rule(
        (str,),
        choices=(
            "GitHub",
            "SolarizedDark",
            "SolarizedLight",
            "EightiesDark",
            "MochaDark",
            "OceanDark",
            "OceanLight",
        ),
    ),
    "terminal_title": _str,
    "graphics_display": Rule((str,), choices=("none", "auto", "kitty", "sixel")),
    "kitty_graphics_transmission": Rule((str,), choices=("chunks", "temp_file")),
    "kitty_graphics_display": Rule((str,), choices=("none", "auto", "direct", "unicode")),
    "kept_kitty_temp_files": _int,
    "preview_transformers": Rule((list,)),
    "lines_before_match_in_preview": _int,
    "lines_after_match_in_preview": _int,
    "enable_kitty_keyboard": _bool,
    "auto_open_staging_area": _bool,
    "max_staged_count": _int,
    "capture_mouse": _bool,
    "file_sum_threads_count": _int,
    "quit_on_last_cancel": _bool,
    "update_work_dir": _bool,
    "show_matching_characters_on_path_searches": _bool,
    "imports": Rule((list,)),
    "verbs": Rule((list,)),
    # user-named maps — keys are paths, extensions, prefixes, color roles
    "special_paths": _table,
    "ext_colors": _table,
    "search-modes": _table,
    "skin": _table,
}

TABLES = {
    "": ROOT,
}
