# griplint-broot

Config linter for [broot](https://dystroy.org/broot) `conf.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
