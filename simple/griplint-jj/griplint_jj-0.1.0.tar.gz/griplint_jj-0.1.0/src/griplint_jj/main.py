"""griplint-jj — config linter for jujutsu (https://jj-vcs.github.io/jj)."""

from griplint_common import serve_linter

from .linter import LINTER


def main() -> None:
    serve_linter(LINTER)


if __name__ == "__main__":
    main()
