"""Key tables for jj (jujutsu) 0.x, `config.toml`.

Source: the official JSON schema (derived per the author skill's
machine-readable-first rule) —
docs.jj-vcs.dev/latest/config-schema.json, expanded 2026-08 (93 fixed
keys, 22 sections). Map sections (aliases, colors, revset-aliases,
template-aliases, fileset-aliases, remotes, merge-tools, hints) are
FREE_FORM — user-defined by nature. Editor-ish keys accept a string or
an argv list. Nested tool tables are type-checked only.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))
_strs = Rule((list,))
_table = Rule((dict,))
_command = Rule((str, list))  # "vim" or ["vim", "-u", "NONE"]
_size = Rule((int, str))  # bytes or "10MB"

USER = {"name": _str, "email": _str}
OPERATION = {"hostname": _str, "username": _str}

UI = {
    "default-command": _command,
    "color": Rule((str,), choices=("always", "never", "debug", "auto")),
    "paginate": Rule((str,), choices=("never", "auto")),
    "pager": _command,
    "streampager": _table,
    "diff-instructions": _bool,
    "graph": _table,
    "log-word-wrap": _bool,
    "log-synthetic-elided-nodes": _bool,
    "editor": _command,
    "diff-editor": _command,
    "diff-formatter": _command,
    "merge-editor": _command,
    "conflict-marker-style": _str,
    "show-cryptographic-signatures": _bool,
    "movement": _table,
    "bookmark-list-sort-keys": _strs,
    "tag-list-sort-keys": _strs,
}

FSMONITOR = {
    "backend": Rule((str,), choices=("none", "watchman")),
    "watchman": _table,
}

DIFF = {"color-words": _table, "git": _table, "stat": _table}

GIT = {
    "abandon-unreachable-commits": _bool,
    "fetch": Rule((str, list)),
    "private-commits": _str,
    "push": _str,
    "record-synthetic-predecessors": _bool,
    "sign-on-push": _bool,
    "track-default-bookmark-on-clone": _bool,
    "write-change-id-header": _bool,
    "executable-path": _str,
    "colocate": _bool,
    "object-hash": Rule((str,), choices=("sha1", "sha256")),
}

GERRIT = {
    "default-remote": _str,
    "default-remote-branch": _str,
    "review-url": _str,
}

MERGE = {
    "hunk-level": Rule((str,), choices=("line", "word")),
    "same-change": Rule((str,), choices=("keep", "accept")),
}

REVSETS = {
    "arrange": _str,
    "fix": _str,
    "log": _str,
    "short-prefixes": _str,
    "run": _str,
    "simplify-parents": _str,
    "sign": _str,
    "log-graph-prioritize": _str,
    "bookmark-advance-to": _str,
    "bookmark-advance-from": _str,
}

RUN = {"jobs": _int}

SNAPSHOT = {
    "auto-track": _str,
    "auto-update-stale": _bool,
    "max-new-file-size": _size,
}

EXPERIMENTAL_ADVANCE_BRANCHES = {
    "enabled-branches": _strs,
    "disabled-branches": _strs,
}

SIGNING = {
    "backend": Rule((str,), choices=("gpg", "gpgsm", "none", "ssh")),
    "key": _str,
    "behavior": Rule((str,), choices=("drop", "keep", "own", "force")),
    "backends": _table,
}

FIX = {"tools": _table}
SPLIT = {"legacy-bookmark-behavior": _bool}

TEMPLATES = {
    "arrange": _str,
    "bookmark_list": _str,
    "commit_summary": _str,
    "commit_trailers": _str,
    "file_annotate": _str,
    "config_list": _str,
    "draft_commit_description": _str,
    "evolog": _str,
    "file_list": _str,
    "file_show": _str,
    "git_push_bookmark": _str,
    "log": _str,
    "op_log": _str,
    "op_show": _str,
    "op_summary": _str,
    "show": _str,
    "revert_description": _str,
    "tag_list": _str,
    "workspace_list": _str,
}

WORKING_COPY = {
    "eol-conversion": Rule((str,), choices=("input", "input-output", "none")),
    "exec-bit-change": Rule((str,), choices=("respect", "ignore", "auto")),
}

WHEN = {
    "repositories": _strs,
    "hostnames": _strs,
    "workspaces": _strs,
    "commands": _strs,
    "platforms": _strs,
    "environments": _strs,
}

TABLES = {
    "user": USER,
    "operation": OPERATION,
    "ui": UI,
    "fsmonitor": FSMONITOR,
    "colors": FREE_FORM,
    "diff": DIFF,
    "fileset-aliases": FREE_FORM,
    "git": GIT,
    "remotes": FREE_FORM,
    "gerrit": GERRIT,
    "merge": MERGE,
    "merge-tools": FREE_FORM,
    "revsets": REVSETS,
    "revset-aliases": FREE_FORM,
    "template-aliases": FREE_FORM,
    "aliases": FREE_FORM,
    "run": RUN,
    "snapshot": SNAPSHOT,
    "experimental-advance-branches": EXPERIMENTAL_ADVANCE_BRANCHES,
    "signing": SIGNING,
    "fix": FIX,
    "split": SPLIT,
    "hints": FREE_FORM,
    "templates": TEMPLATES,
    "working-copy": WORKING_COPY,
    "--when": WHEN,
    "--scope": FREE_FORM,
}
