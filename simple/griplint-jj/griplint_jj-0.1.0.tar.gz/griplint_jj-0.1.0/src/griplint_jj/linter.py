"""griplint-jj pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. Alias/color/hint map sections are FREE_FORM —
#  user-defined by nature. Conditional [--when] sections are tabulated;
#  nested tool tables (merge-tools, fix.tools) are type-checked only.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="jj",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
