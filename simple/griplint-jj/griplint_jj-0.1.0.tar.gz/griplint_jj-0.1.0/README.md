# griplint-jj

Config linter for [jujutsu](https://jj-vcs.github.io/jj) `config.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
