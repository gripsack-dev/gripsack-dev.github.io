# griplint-television

Config linter for [television](https://alexpasmantier.github.io/television) `config.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
