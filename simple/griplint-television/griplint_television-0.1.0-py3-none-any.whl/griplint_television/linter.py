"""griplint-television pipeline: what we lint, with which tables and passes.

Only `config.toml` is linted. Cable channel files (cable/*.toml) have
#  arbitrary basenames — they need path-pattern handles in the engine
#  (TODO: same engine feature as pyproject section extraction).
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="television",
    handles={"config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
