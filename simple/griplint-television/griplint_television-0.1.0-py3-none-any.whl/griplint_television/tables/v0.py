"""Key tables for television 0.x, `config.toml`.

Source: docs/user-guide/02-configuration.md "Option reference" in
alexpasmantier/television (read 2026-08) plus the shipped default
.config/config.toml. `[keybindings]` and
`[shell_integration.channel_triggers]` are user-defined maps →
FREE_FORM. `[ui.theme_overrides]` color keys are the documented fixed
set.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_int = Rule((int,))
_str = Rule((str,))

#: bare top-level keys — docs: "General Settings"
ROOT = {
    "tick_rate": _int,
    "default_channel": _str,
    "history_size": _int,
    "global_history": _bool,
}

UI = {  # docs: "UI Configuration"
    "ui_scale": _int,
    "orientation": Rule((str,), choices=("landscape", "portrait")),
    "theme": _str,
}

INPUT_BAR = {  # docs: [ui.input_bar]
    "position": Rule((str,), choices=("top", "bottom")),
    "prompt": _str,
    "border_type": _str,
}

STATUS_BAR = {"hidden": _bool}  # docs: [ui.status_bar]

RESULTS_PANEL = {"border_type": _str}  # docs: [ui.results_panel]

PREVIEW_PANEL = {  # docs: [ui.preview_panel]
    "size": _int,
    "scrollbar": _bool,
    "border_type": _str,
    "hidden": _bool,
}

HELP_PANEL = {  # docs: [ui.help_panel]
    "show_categories": _bool,
    "hidden": _bool,
}

REMOTE_CONTROL = {  # docs: [ui.remote_control]
    "show_channel_descriptions": _bool,
    "sort_alphabetically": _bool,
}

THEME_OVERRIDES = {  # docs: [ui.theme_overrides] — the fixed color key set
    "background": _str,
    "border_fg": _str,
    "text_fg": _str,
    "dimmed_text_fg": _str,
    "input_text_fg": _str,
    "result_count_fg": _str,
    "result_name_fg": _str,
    "result_line_number_fg": _str,
    "result_value_fg": _str,
    "selection_bg": _str,
    "selection_fg": _str,
    "match_fg": _str,
    "preview_title_fg": _str,
    "channel_mode_fg": _str,
    "channel_mode_bg": _str,
    "remote_control_mode_fg": _str,
    "remote_control_mode_bg": _str,
}

SHELL_INTEGRATION = {  # docs: [shell_integration]
    "fallback_channel": _str,
}

SHELL_KEYBINDINGS = {  # docs: [shell_integration.keybindings]
    "smart_autocomplete": _str,
    "command_history": _str,
}

TABLES = {
    "": ROOT,
    "ui": UI,
    "ui.input_bar": INPUT_BAR,
    "ui.status_bar": STATUS_BAR,
    "ui.results_panel": RESULTS_PANEL,
    "ui.preview_panel": PREVIEW_PANEL,
    "ui.help_panel": HELP_PANEL,
    "ui.remote_control": REMOTE_CONTROL,
    "ui.theme_overrides": THEME_OVERRIDES,
    "keybindings": FREE_FORM,
    "shell_integration": SHELL_INTEGRATION,
    "shell_integration.channel_triggers": FREE_FORM,
    "shell_integration.keybindings": SHELL_KEYBINDINGS,
}
