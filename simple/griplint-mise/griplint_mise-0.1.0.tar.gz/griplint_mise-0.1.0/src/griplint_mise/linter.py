"""griplint-mise pipeline: what we lint, with which tables and passes.

Both `mise.toml` and `config.toml` are linted. `[tools]`, `[tasks]`,
#  `[alias]`, `[plugins]`, `[vars]` et al. are user-defined maps: FREE_FORM.
#  Backend option tables (settings.python et al.) are type-checked only.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="mise",
    handles={"mise.toml", "config.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
