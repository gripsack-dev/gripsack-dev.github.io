# griplint-mise

Config linter for [mise](https://mise.jdx.dev) `mise.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
