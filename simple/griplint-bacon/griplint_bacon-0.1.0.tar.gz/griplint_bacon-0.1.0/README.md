# griplint-bacon

Config linter for [bacon](https://dystroy.org/bacon) `bacon.toml` — a `griplint-*` validation plugin for [gripsack](https://gripsack.dev). See the [griplint-py repo](https://github.com/gripsack-dev/griplint-py) for usage.
