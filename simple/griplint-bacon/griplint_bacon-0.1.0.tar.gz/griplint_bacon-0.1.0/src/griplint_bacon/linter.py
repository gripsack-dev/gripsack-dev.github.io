"""griplint-bacon pipeline: what we lint, with which tables and passes.

Both `bacon.toml` (project) and `prefs.toml` (global) are linted — same
#  format per the docs. `[jobs.*]`, `[keybindings]`, `[exports.*]` are
#  user-named maps: FREE_FORM. Root keys double as job-default fields.
"""

from griplint_common import Linter

from . import tables

LINTER = Linter(
    name="bacon",
    handles={"bacon.toml", "prefs.toml"},
    resolve_table=tables.resolve,
    checks=[],
)
