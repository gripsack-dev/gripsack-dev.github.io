"""Key tables for bacon 3.x, `bacon.toml` / `prefs.toml`.

Sources: dystroy.org/bacon/config (the job-properties table — these
double as root-level defaults) plus the shipped defaults
(github.com/Canop/bacon defaults/default-prefs.toml: [sound],
[exports.locations]). `[jobs.*]`, `[keybindings]`, and `[exports.*]`
are user-named maps → FREE_FORM.
"""

from griplint_common import FREE_FORM, Rule

_bool = Rule((bool,))
_str = Rule((str,))
_strs = Rule((list,))

#: bare top-level keys — docs: "Job Properties" (they apply to all
#: jobs unless overridden) plus the Settings struct fields
#: (src/conf/settings.rs: summary, wrap, features, …)
ROOT = {
    "default_job": _str,
    "additional_alias_args": _strs,
    "additional_job_args": _strs,
    "all_features": _bool,
    "features": _str,
    "help_line": _bool,
    "no_default_features": _bool,
    "reverse": _bool,
    "summary": _bool,
    "wrap": _bool,
    "listen": _bool,
    "allow_failures": _bool,
    "allow_warnings": _bool,
    "analyzer": _str,
    "apply_gitignore": _bool,
    "background": _bool,
    "command": _strs,
    "default_watch": _bool,
    "env": Rule((dict,)),
    "hide_scrollbar": _bool,
    "kill": _strs,
    "ignore": _strs,
    "ignored_lines": _strs,
    "extraneous_args": _bool,
    "need_stdout": _bool,
    "on_change_strategy": Rule((str,), choices=("wait_then_restart", "kill_then_restart")),
    "on_success": _str,
    "show_command_error_code": _bool,
    "scroll_anchor": Rule((str,), choices=("first", "last", "auto")),
    "skin": Rule((dict,)),
    "watch": _strs,
    "workdir": _str,
}

SOUND = {  # source: default-prefs.toml [sound]
    "enabled": _bool,
    "base_volume": _str,
}

TABLES = {
    "": ROOT,
    "jobs": FREE_FORM,  # user-named jobs
    "keybindings": FREE_FORM,  # user key combinations → actions
    "exports": FREE_FORM,  # user-named exports
    "sound": SOUND,
}
